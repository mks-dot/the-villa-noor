"use client";

/**
 * Client-side admin session.
 * The token is stored in localStorage on login and sent as an
 * `Authorization: Bearer` header with every API call, so saving works
 * even when the browser blocks third-party cookies (e.g. inside previews).
 */

const KEY = "azura_admin_token";

export function getAdminToken(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}

export function setAdminToken(token: string) {
  try {
    localStorage.setItem(KEY, token);
  } catch {
    /* storage unavailable */
  }
}

export function clearAdminToken() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

/** fetch wrapper that always sends cookies + the admin token (when present). */
export async function apiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  const headers = new Headers(init?.headers ?? {});
  if (!headers.has("Authorization")) {
    const token = getAdminToken();
    if (token) headers.set("Authorization", `Bearer ${token}`);
  }
  return fetch(input, { ...init, headers, credentials: "include" });
}

/** Extract a human-readable error message from a failed API response. */
export async function apiErrorMessage(res: Response, fallback: string): Promise<string> {
  if (res.status === 401) return "Not logged in — please log in again and retry.";
  try {
    const data = (await res.json()) as { error?: string };
    if (data?.error && typeof data.error === "string") return data.error;
  } catch {
    /* not JSON */
  }
  return `${fallback} (error ${res.status})`;
}
