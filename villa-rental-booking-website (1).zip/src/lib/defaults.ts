export type FieldType = "text" | "textarea" | "image" | "number";

export type ContentDef = {
  key: string;
  value: string;
  type: FieldType;
  label: string;
  section: string;
};

export const IMG = {
  hero: "https://images.pexels.com/photos/7031407/pexels-photo-7031407.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  extA:
    "https://images.pexels.com/photos/29560257/pexels-photo-29560257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  extB:
    "https://images.pexels.com/photos/19162028/pexels-photo-19162028.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  extC:
    "https://images.pexels.com/photos/13600823/pexels-photo-13600823.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  extD:
    "https://images.pexels.com/photos/10425285/pexels-photo-10425285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  garden:
    "https://images.pexels.com/photos/14024990/pexels-photo-14024990.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  livingA:
    "https://images.pexels.com/photos/7836571/pexels-photo-7836571.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  livingB:
    "https://images.pexels.com/photos/7546721/pexels-photo-7546721.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  kitchen1:
    "https://images.pexels.com/photos/8146322/pexels-photo-8146322.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bath1:
    "https://images.pexels.com/photos/6957081/pexels-photo-6957081.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  dining:
    "https://images.pexels.com/photos/7061420/pexels-photo-7061420.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  hall: "https://images.pexels.com/photos/6957083/pexels-photo-6957083.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  plants:
    "https://images.pexels.com/photos/6283965/pexels-photo-6283965.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bedroom1:
    "https://images.pexels.com/photos/29000312/pexels-photo-29000312.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bedroom2:
    "https://images.pexels.com/photos/14025909/pexels-photo-14025909.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bedroom3:
    "https://images.pexels.com/photos/6394574/pexels-photo-6394574.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  terrace:
    "https://images.pexels.com/photos/19075381/pexels-photo-19075381.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

export const DEFAULT_CONTENT: ContentDef[] = [
  // Brand
  { key: "site.name", value: "Azura Villas", type: "text", label: "Site name", section: "Brand" },
  { key: "site.tagline", value: "Modern villas by the sea", type: "text", label: "Tagline", section: "Brand" },
  // Hero
  { key: "hero.eyebrow", value: "Uluwatu · Bali · Modern Villas", type: "text", label: "Hero eyebrow", section: "Hero" },
  { key: "hero.title", value: "Modern comfort near the ocean.", type: "text", label: "Hero title", section: "Hero" },
  { key: "hero.subtitle", value: "Modern 2-bedroom villas with designer interiors, full kitchens and breezy terraces — minutes from the beach, cafes and surf.", type: "textarea", label: "Hero subtitle", section: "Hero" },
  { key: "hero.image", value: IMG.hero, type: "image", label: "Hero background image", section: "Hero" },
  { key: "hero.cta_primary", value: "Book your stay", type: "text", label: "Primary button text", section: "Hero" },
  { key: "hero.cta_secondary", value: "Explore villas", type: "text", label: "Secondary button text", section: "Hero" },
  // Stats
  { key: "stats.villas", value: "4", type: "number", label: "Number of villas", section: "Stats" },
  { key: "stats.guests", value: "12k+", type: "text", label: "Happy guests", section: "Stats" },
  { key: "stats.rating", value: "4.98", type: "text", label: "Average rating", section: "Stats" },
  { key: "stats.years", value: "12", type: "number", label: "Years hosting", section: "Stats" },
  // Villas section
  { key: "villas.eyebrow", value: "Our villas", type: "text", label: "Section eyebrow", section: "Villas" },
  { key: "villas.title", value: "Modern 2-bedroom retreats.", type: "text", label: "Section title", section: "Villas" },
  { key: "villas.subtitle", value: "Every villa is a modern 2-bedroom, 2-bathroom retreat with a full kitchen, fast Wi-Fi and daily housekeeping. Pick the style you love.", type: "textarea", label: "Section subtitle", section: "Villas" },
  // Experience
  { key: "experience.eyebrow", value: "The Azura experience", type: "text", label: "Section eyebrow", section: "Experience" },
  { key: "experience.title", value: "Everything is taken care of", type: "text", label: "Section title", section: "Experience" },
  { key: "experience.subtitle", value: "Everything in the villa just works — full kitchen, fast Wi-Fi, daily housekeeping and a local host one message away.", type: "textarea", label: "Section subtitle", section: "Experience" },
  { key: "experience.image", value: IMG.terrace, type: "image", label: "Experience side image", section: "Experience" },
  // Gallery
  { key: "gallery.eyebrow", value: "Gallery", type: "text", label: "Section eyebrow", section: "Gallery" },
  { key: "gallery.title", value: "Postcards from Azura", type: "text", label: "Section title", section: "Gallery" },
  { key: "gallery.subtitle", value: "Shot on the estate — bright suites, modern kitchens, terraces and the sunsets we never get tired of.", type: "textarea", label: "Section subtitle", section: "Gallery" },
  // Reviews
  { key: "reviews.eyebrow", value: "Guest stories", type: "text", label: "Section eyebrow", section: "Reviews" },
  { key: "reviews.title", value: "They came for a week…", type: "text", label: "Section title", section: "Reviews" },
  { key: "reviews.subtitle", value: "Real reviews from verified stays at Azura Villas.", type: "textarea", label: "Section subtitle", section: "Reviews" },
  // Booking
  { key: "booking.eyebrow", value: "Reserve", type: "text", label: "Section eyebrow", section: "Booking" },
  { key: "booking.title", value: "Check availability", type: "text", label: "Section title", section: "Booking" },
  { key: "booking.subtitle", value: "Send a request and our host replies within 2 hours — with availability, best rate and airport pickup.", type: "textarea", label: "Section subtitle", section: "Booking" },
  // Contact / footer
  { key: "contact.address", value: "Jl. Pantai Suluban No. 88, Uluwatu, Bali", type: "text", label: "Address", section: "Contact" },
  { key: "contact.phone", value: "+62 361 908 1122", type: "text", label: "Phone", section: "Contact" },
  { key: "contact.email", value: "stay@azuravillas.com", type: "text", label: "Email", section: "Contact" },
  { key: "contact.hours", value: "Host support 7 AM – 10 PM · Check-in from 2 PM", type: "text", label: "Hours note", section: "Contact" },
  { key: "footer.note", value: "© 2026 Azura Villas. Crafted with salt air and sunlight.", type: "text", label: "Footer note", section: "Contact" },
];

export const DEFAULT_VILLAS = [
  {
    name: "Villa Ocean",
    slug: "villa-ocean",
    tagline: "Light-filled modern 2-bedroom with garden terrace",
    description:
      "A calm, modern 2-bedroom, 2-bathroom villa built for slow Bali days. The open living room flows onto a shaded terrace, both bedrooms have king beds with blackout curtains, and the kitchen is fully equipped for real cooking. Fast Wi-Fi, smart TVs and daily housekeeping included, with the beach a 5-minute walk away.",
    pricePerNight: 220,
    bedrooms: 2,
    bathrooms: 2,
    maxGuests: 4,
    sizeSqm: 120,
    coverImage: IMG.extA,
    images: [IMG.extA, IMG.livingA, IMG.bedroom1, IMG.dining],
    amenities: ["2 bedrooms", "2 bathrooms", "Full modern kitchen", "Garden terrace", "Fast Wi-Fi", "Smart TV", "Air conditioning", "Daily housekeeping"],
    featured: true,
    sortOrder: 0,
  },
  {
    name: "Villa Palm",
    slug: "villa-palm",
    tagline: "Cozy modern 2-bedroom tucked into the garden",
    description:
      "Tucked behind banana palms, Villa Palm is a quiet modern 2-bedroom, 2-bathroom hideaway. Cool polished-concrete floors, a comfy lounge with smart TV, two serene bedrooms and a kitchen stocked for slow breakfasts on the terrace. Daily housekeeping keeps everything spotless.",
    pricePerNight: 170,
    bedrooms: 2,
    bathrooms: 2,
    maxGuests: 4,
    sizeSqm: 105,
    coverImage: IMG.extB,
    images: [IMG.extB, IMG.plants, IMG.bedroom2, IMG.kitchen1],
    amenities: ["2 bedrooms", "2 bathrooms", "Full modern kitchen", "Terrace dining", "Fast Wi-Fi", "Smart TV", "Air conditioning", "Daily housekeeping"],
    featured: true,
    sortOrder: 1,
  },
  {
    name: "Villa Stone",
    slug: "villa-stone",
    tagline: "Modern 2-bedroom with warm stone and timber",
    description:
      "Villa Stone pairs modern comfort with natural textures — volcanic stone walls, teak furniture and soft linen everywhere. Two bedrooms, two rainfall-shower bathrooms, an open kitchen and a reading corner made for rainy afternoons. Cafes and the beach are minutes away.",
    pricePerNight: 190,
    bedrooms: 2,
    bathrooms: 2,
    maxGuests: 4,
    sizeSqm: 115,
    coverImage: IMG.extC,
    images: [IMG.extC, IMG.hall, IMG.bedroom3, IMG.bath1],
    amenities: ["2 bedrooms", "2 bathrooms", "Rainfall showers", "Full modern kitchen", "Reading corner", "Fast Wi-Fi", "Smart TV", "Daily housekeeping"],
    featured: true,
    sortOrder: 2,
  },
  {
    name: "Villa Light",
    slug: "villa-light",
    tagline: "Bright top-floor modern 2-bedroom for families",
    description:
      "The brightest villa on the estate — a top-floor modern 2-bedroom, 2-bathroom with big windows, a dining table for six and a lounge that fits the whole family. Kids get the twin room, grown-ups get the king suite, and everyone gets fast Wi-Fi and total quiet after 10 PM.",
    pricePerNight: 240,
    bedrooms: 2,
    bathrooms: 2,
    maxGuests: 4,
    sizeSqm: 135,
    coverImage: IMG.extD,
    images: [IMG.extD, IMG.livingB, IMG.dining, IMG.terrace],
    amenities: ["2 bedrooms", "2 bathrooms", "Dining for six", "Full modern kitchen", "Family lounge", "Fast Wi-Fi", "Smart TV", "Daily housekeeping"],
    featured: true,
    sortOrder: 3,
  },
];

export const DEFAULT_GALLERY = [
  { url: IMG.hero, caption: "The estate at dusk", category: "Exterior", sortOrder: 0 },
  { url: IMG.extA, caption: "Villa exterior among the palms", category: "Exterior", sortOrder: 1 },
  { url: IMG.livingA, caption: "Open-plan living room", category: "Interior", sortOrder: 2 },
  { url: IMG.kitchen1, caption: "Fully equipped kitchen", category: "Interior", sortOrder: 3 },
  { url: IMG.bedroom1, caption: "King master suite", category: "Suites", sortOrder: 4 },
  { url: IMG.bath1, caption: "Modern rainfall bathroom", category: "Interior", sortOrder: 5 },
  { url: IMG.dining, caption: "Dining for six", category: "Dining", sortOrder: 6 },
  { url: IMG.terrace, caption: "Terrace dinner at golden hour", category: "Dining", sortOrder: 7 },
  { url: IMG.garden, caption: "Garden path to the villas", category: "Exterior", sortOrder: 8 },
];

export const DEFAULT_TESTIMONIALS = [
  {
    guestName: "Sofia Marchetti",
    location: "Milan, Italy",
    villaName: "Villa Ocean",
    rating: 5,
    text: "Spotlessly clean and so quiet. The kitchen had everything, the beds were super comfy and the host sorted our airport pickup in minutes. Best value 2-bedroom we found in Uluwatu.",
    stayDate: "August 2026",
    approved: true,
  },
  {
    guestName: "James & Priya Whitfield",
    location: "London, UK",
    villaName: "Villa Light",
    rating: 5,
    text: "Two couples, plenty of space, zero complaints. Fast Wi-Fi for remote work, great water pressure and daily housekeeping. We ended up extending by three nights.",
    stayDate: "July 2026",
    approved: true,
  },
  {
    guestName: "Daniel Okafor",
    location: "Lagos, Nigeria",
    villaName: "Villa Stone",
    rating: 5,
    text: "I came to work remotely for a month and the setup was perfect — proper desk, blackout curtains, quiet AC. The modern design looks even better in person.",
    stayDate: "June 2026",
    approved: true,
  },
];
