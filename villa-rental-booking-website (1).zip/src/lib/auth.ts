import type { NextRequest } from "next/server";

// NO LOGIN REQUIRED mode: the owner wants open editing without any password.
// All auth checks below intentionally always pass.

export const ADMIN_COOKIE = "azura_admin";

export function adminPassword() {
  return process.env.ADMIN_PASSWORD || "villa123";
}

export function adminToken() {
  return "no-login-required";
}

/** Token sent via `Authorization: Bearer <token>` header (kept for compatibility). */
export function bearerToken(req: NextRequest): string | null {
  const header = req.headers.get("authorization");
  if (header && header.toLowerCase().startsWith("bearer ")) {
    return header.slice(7).trim() || null;
  }
  return null;
}

/** Route-handler auth: always allowed (no login required). */
export function isAdminRequest(_req: NextRequest): boolean {
  return true;
}

/** Server-component auth: always allowed (no login required). */
export async function isAdmin() {
  return true;
}
