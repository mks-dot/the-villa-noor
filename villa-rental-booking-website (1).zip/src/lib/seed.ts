import { sql } from "drizzle-orm";
import { db } from "@/db";
import { galleryImages, siteContent, testimonials, villas } from "@/db/schema";
import { DEFAULT_CONTENT, DEFAULT_GALLERY, DEFAULT_TESTIMONIALS, DEFAULT_VILLAS } from "./defaults";

/**
 * Self-bootstrap for fresh databases (e.g. a brand-new Vercel Postgres).
 * Creates every table if missing, then seeds the default content.
 * Safe to run on every cold start — it is all IF NOT EXISTS + "seed only if empty".
 */
const TABLE_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS "site_content" (
    "key" text PRIMARY KEY,
    "value" text DEFAULT '' NOT NULL,
    "type" text DEFAULT 'text' NOT NULL,
    "label" text DEFAULT '' NOT NULL,
    "section" text DEFAULT 'general' NOT NULL,
    "updated_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "villas" (
    "id" serial PRIMARY KEY,
    "name" text NOT NULL,
    "slug" text NOT NULL UNIQUE,
    "tagline" text DEFAULT '' NOT NULL,
    "description" text DEFAULT '' NOT NULL,
    "price_per_night" integer DEFAULT 0 NOT NULL,
    "bedrooms" integer DEFAULT 1 NOT NULL,
    "bathrooms" integer DEFAULT 1 NOT NULL,
    "max_guests" integer DEFAULT 2 NOT NULL,
    "size_sqm" integer DEFAULT 0 NOT NULL,
    "cover_image" text DEFAULT '' NOT NULL,
    "images" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "amenities" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "featured" boolean DEFAULT false NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "updated_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "gallery_images" (
    "id" serial PRIMARY KEY,
    "url" text NOT NULL,
    "caption" text DEFAULT '' NOT NULL,
    "category" text DEFAULT 'Villa' NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "testimonials" (
    "id" serial PRIMARY KEY,
    "guest_name" text NOT NULL,
    "location" text DEFAULT '' NOT NULL,
    "villa_name" text DEFAULT '' NOT NULL,
    "rating" integer DEFAULT 5 NOT NULL,
    "text" text NOT NULL,
    "stay_date" text DEFAULT '' NOT NULL,
    "approved" boolean DEFAULT false NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS "bookings" (
    "id" serial PRIMARY KEY,
    "villa_id" integer,
    "villa_name" text DEFAULT '' NOT NULL,
    "name" text NOT NULL,
    "email" text NOT NULL,
    "phone" text DEFAULT '' NOT NULL,
    "check_in" text DEFAULT '' NOT NULL,
    "check_out" text DEFAULT '' NOT NULL,
    "guests" integer DEFAULT 2 NOT NULL,
    "message" text DEFAULT '' NOT NULL,
    "status" text DEFAULT 'pending' NOT NULL,
    "created_at" timestamp DEFAULT now() NOT NULL,
    "updated_at" timestamp DEFAULT now() NOT NULL
  )`,
];

let bootstrapped = false;

export async function ensureTables() {
  if (bootstrapped) return;
  for (const statement of TABLE_STATEMENTS) {
    await db.execute(sql.raw(statement));
  }
  bootstrapped = true;
}

let seeded = false;

export async function ensureSeeded() {
  if (seeded) return;
  try {
    await ensureTables();
    const existing = await db.select({ key: siteContent.key }).from(siteContent).limit(1);
    if (existing.length > 0) {
      seeded = true;
      return;
    }
    await db.insert(siteContent).values(DEFAULT_CONTENT).onConflictDoNothing();
    await db.insert(villas).values(DEFAULT_VILLAS).onConflictDoNothing();
    await db.insert(galleryImages).values(DEFAULT_GALLERY);
    await db.insert(testimonials).values(DEFAULT_TESTIMONIALS);
    seeded = true;
  } catch (err) {
    console.error("Seed failed:", err);
  }
}

export async function contentMap(): Promise<Record<string, string>> {
  await ensureSeeded();
  const rows = await db.select().from(siteContent);
  const map: Record<string, string> = {};
  for (const def of DEFAULT_CONTENT) map[def.key] = def.value;
  for (const row of rows) map[row.key] = row.value;
  return map;
}
