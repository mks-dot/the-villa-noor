import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

// Local dev uses DATABASE_URL. Vercel Postgres / Neon also provide POSTGRES_URL,
// so accept either — whichever is set wins.
const databaseUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const isLocal = databaseUrl.includes("127.0.0.1") || databaseUrl.includes("localhost");

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    // Hosted Postgres (Neon / Vercel / Supabase) requires SSL; local does not.
    ssl: isLocal ? undefined : { rejectUnauthorized: false },
    // Small pool: serverless functions must not hold many connections open.
    max: 5,
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 10_000,
  });

// Always cache on globalThis so reloads and serverless re-use share one pool
// instead of leaking connections.
globalForDb.__arenaNextJsPostgresqlPool = pool;

export const db = drizzle(pool);
