import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/** Key-value site content powers the visual edit tool (every text/image on the site). */
export const siteContent = pgTable("site_content", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
  type: text("type").notNull().default("text"),
  label: text("label").notNull().default(""),
  section: text("section").notNull().default("general"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const villas = pgTable("villas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline").notNull().default(""),
  description: text("description").notNull().default(""),
  pricePerNight: integer("price_per_night").notNull().default(0),
  bedrooms: integer("bedrooms").notNull().default(1),
  bathrooms: integer("bathrooms").notNull().default(1),
  maxGuests: integer("max_guests").notNull().default(2),
  sizeSqm: integer("size_sqm").notNull().default(0),
  coverImage: text("cover_image").notNull().default(""),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  amenities: jsonb("amenities").$type<string[]>().notNull().default([]),
  featured: boolean("featured").notNull().default(false),
  active: boolean("active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const galleryImages = pgTable("gallery_images", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  caption: text("caption").notNull().default(""),
  category: text("category").notNull().default("Villa"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  guestName: text("guest_name").notNull(),
  location: text("location").notNull().default(""),
  villaName: text("villa_name").notNull().default(""),
  rating: integer("rating").notNull().default(5),
  text: text("text").notNull(),
  stayDate: text("stay_date").notNull().default(""),
  approved: boolean("approved").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  villaId: integer("villa_id"),
  villaName: text("villa_name").notNull().default(""),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull().default(""),
  checkIn: text("check_in").notNull().default(""),
  checkOut: text("check_out").notNull().default(""),
  guests: integer("guests").notNull().default(2),
  message: text("message").notNull().default(""),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type SiteContentRow = typeof siteContent.$inferSelect;
export type Villa = typeof villas.$inferSelect;
export type NewVilla = typeof villas.$inferInsert;
export type GalleryImage = typeof galleryImages.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
