"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  BedDouble,
  CalendarCheck,
  Check,
  Eye,
  EyeOff,
  ImagePlus,
  Images,
  LayoutDashboard,
  Loader2,
  MessageSquareHeart,
  Pencil,
  Plus,
  SlidersHorizontal,
  Star,
  Trash2,
  Home,
} from "lucide-react";
import type { Booking, GalleryImage, Testimonial, Villa as VillaType } from "@/db/schema";
import { useEdit } from "../edit/EditContext";
import { VillaFormModal } from "../site/VillaFormModal";
import { Stars } from "../site/ReviewsSection";
import { DEFAULT_CONTENT } from "@/lib/defaults";
import { cn } from "@/lib/cn";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

type Tab = "overview" | "bookings" | "villas" | "gallery" | "reviews" | "content";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "bookings", label: "Bookings", icon: CalendarCheck },
  { id: "villas", label: "Villas", icon: Home },
  { id: "gallery", label: "Gallery", icon: Images },
  { id: "reviews", label: "Reviews", icon: MessageSquareHeart },
  { id: "content", label: "Site text", icon: SlidersHorizontal },
];

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  confirmed: "bg-emerald-100 text-emerald-800",
  cancelled: "bg-stone-200 text-stone-600",
};

export function AdminDashboard() {
  const { toast, content, saveMany, saving, refreshContent } = useEdit();
  const [tab, setTab] = useState<Tab>("overview");
  const [loading, setLoading] = useState(true);

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [villas, setVillas] = useState<VillaType[]>([]);
  const [gallery, setGallery] = useState<GalleryImage[]>([]);
  const [reviews, setReviews] = useState<Testimonial[]>([]);
  const [formVilla, setFormVilla] = useState<VillaType | null | undefined>(undefined);

  // Add-photo form
  const [photoUrl, setPhotoUrl] = useState("");
  const [photoCaption, setPhotoCaption] = useState("");
  const [photoCategory, setPhotoCategory] = useState("Villa");
  const [photoBusy, setPhotoBusy] = useState(false);

  // Content drafts
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [contentFilter, setContentFilter] = useState("");

  const refreshAll = useCallback(async () => {
    setLoading(true);
    try {
      const [b, v, g, r] = await Promise.all([
        apiFetch("/api/bookings").then((x) => x.json()),
        apiFetch("/api/villas").then((x) => x.json()),
        apiFetch("/api/gallery").then((x) => x.json()),
        apiFetch("/api/testimonials?all=1").then((x) => x.json()),
      ]);
      if (b.bookings) setBookings(b.bookings);
      if (v.villas) setVillas(v.villas);
      if (g.gallery) setGallery(g.gallery);
      if (r.testimonials) setReviews(r.testimonials);
    } catch {
      toast("Could not load data", "error");
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    refreshAll();
  }, [refreshAll]);

  useEffect(() => {
    setDrafts({ ...content });
  }, [content]);

  const pendingBookings = bookings.filter((b) => b.status === "pending");
  const pendingReviews = reviews.filter((r) => !r.approved);

  const dirtyContent = useMemo(
    () => DEFAULT_CONTENT.filter((d) => (drafts[d.key] ?? "") !== (content[d.key] ?? "")),
    [drafts, content]
  );

  const contentSections = useMemo(() => {
    const groups = new Map<string, typeof DEFAULT_CONTENT>();
    for (const def of DEFAULT_CONTENT) {
      if (
        contentFilter &&
        !`${def.label} ${def.key} ${def.section}`.toLowerCase().includes(contentFilter.toLowerCase())
      )
        continue;
      if (!groups.has(def.section)) groups.set(def.section, []);
      groups.get(def.section)!.push(def);
    }
    return [...groups.entries()];
  }, [contentFilter]);

  const setBookingStatus = async (id: number, status: string) => {
    const res = await apiFetch(`/api/bookings/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)));
      toast(`Booking ${status}`, "success");
    } else {
      toast(await apiErrorMessage(res, "Could not update booking"), "error");
    }
  };

  const deleteBooking = async (id: number) => {
    if (!confirm("Delete this booking request?")) return;
    const res = await apiFetch(`/api/bookings/${id}`, { method: "DELETE" });
    if (res.ok) {
      setBookings((prev) => prev.filter((b) => b.id !== id));
      toast("Booking deleted", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not delete booking"), "error");
    }
  };

  const deleteVilla = async (v: VillaType) => {
    if (!confirm(`Delete ${v.name}? This cannot be undone.`)) return;
    const res = await apiFetch(`/api/villas/${v.id}`, { method: "DELETE" });
    if (res.ok) {
      setVillas((prev) => prev.filter((x) => x.id !== v.id));
      toast("Villa deleted", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not delete villa"), "error");
    }
  };

  const toggleVilla = async (v: VillaType) => {
    const res = await apiFetch(`/api/villas/${v.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !v.active }),
    });
    if (res.ok) {
      setVillas((prev) => prev.map((x) => (x.id === v.id ? { ...x, active: !x.active } : x)));
      toast(v.active ? "Villa hidden from site" : "Villa is live", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not update villa"), "error");
    }
  };

  const deletePhoto = async (id: number) => {
    if (!confirm("Delete this photo?")) return;
    const res = await apiFetch(`/api/gallery/${id}`, { method: "DELETE" });
    if (res.ok) {
      setGallery((prev) => prev.filter((x) => x.id !== id));
      toast("Photo deleted", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not delete photo"), "error");
    }
  };

  const addPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoUrl.trim()) return;
    setPhotoBusy(true);
    try {
      const res = await apiFetch("/api/gallery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: photoUrl.trim(),
          caption: photoCaption.trim(),
          category: photoCategory,
          sortOrder: gallery.length,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; image?: GalleryImage };
      if (!res.ok) throw new Error(data?.error || "Could not add photo");
      const newImage = data.image;
      if (newImage) setGallery((prev) => [...prev, newImage]);
      setPhotoUrl("");
      setPhotoCaption("");
      toast("Photo added \u2713", "success");
    } catch (err) {
      toast(err instanceof Error ? err.message : "Could not add photo", "error");
    } finally {
      setPhotoBusy(false);
    }
  };

  const approveReview = async (id: number) => {
    const res = await apiFetch(`/api/testimonials/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approved: true }),
    });
    if (res.ok) {
      setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, approved: true } : r)));
      toast("Review published", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not publish review"), "error");
    }
  };

  const deleteReview = async (id: number) => {
    if (!confirm("Delete this review?")) return;
    const res = await apiFetch(`/api/testimonials/${id}`, { method: "DELETE" });
    if (res.ok) {
      setReviews((prev) => prev.filter((r) => r.id !== id));
      toast("Review deleted", "success");
    } else {
      toast(await apiErrorMessage(res, "Could not delete review"), "error");
    }
  };

  return (
    <div className="min-h-screen bg-stone-100">
      <header className="sticky top-0 z-40 border-b border-stone-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-stone-950 font-display text-lg font-bold text-amber-400">
              A
            </span>
            <div className="leading-tight">
              <p className="font-bold text-stone-900">Azura Villas</p>
              <p className="text-xs text-stone-500">Site manager</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/"
              className="flex items-center gap-1.5 rounded-full border border-stone-300 px-4 py-2 text-sm font-semibold text-stone-700 transition hover:bg-stone-50"
            >
              <ArrowLeft className="h-4 w-4" /> View site
            </Link>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-5 pb-3">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition",
                tab === t.id ? "bg-stone-950 text-white" : "text-stone-500 hover:bg-stone-200/60 hover:text-stone-800"
              )}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
              {t.id === "bookings" && pendingBookings.length > 0 && (
                <span className="rounded-full bg-amber-400 px-1.5 py-0.5 text-[11px] font-bold text-amber-950">
                  {pendingBookings.length}
                </span>
              )}
              {t.id === "reviews" && pendingReviews.length > 0 && (
                <span className="rounded-full bg-amber-400 px-1.5 py-0.5 text-[11px] font-bold text-amber-950">
                  {pendingReviews.length}
                </span>
              )}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-8">
        {loading ? (
          <div className="grid place-items-center py-24 text-stone-400">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <>
            {tab === "overview" && (
              <div className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {[
                    { icon: CalendarCheck, label: "Booking requests", value: bookings.length, sub: `${pendingBookings.length} pending`, go: "bookings" as Tab },
                    { icon: Home, label: "Villas", value: villas.length, sub: `${villas.filter((v) => v.active).length} live`, go: "villas" as Tab },
                    { icon: Images, label: "Gallery photos", value: gallery.length, sub: "on the site", go: "gallery" as Tab },
                    { icon: Star, label: "Reviews", value: reviews.length, sub: `${pendingReviews.length} awaiting approval`, go: "reviews" as Tab },
                  ].map((s) => (
                    <button
                      key={s.label}
                      type="button"
                      onClick={() => setTab(s.go)}
                      className="rounded-2xl bg-white p-5 text-left shadow-sm transition hover:shadow-md"
                    >
                      <span className="grid h-10 w-10 place-items-center rounded-xl bg-amber-100 text-amber-800">
                        <s.icon className="h-5 w-5" />
                      </span>
                      <p className="mt-3 font-display text-3xl font-semibold text-stone-900">{s.value}</p>
                      <p className="text-sm font-medium text-stone-600">{s.label}</p>
                      <p className="text-xs text-stone-400">{s.sub}</p>
                    </button>
                  ))}
                </div>

                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="rounded-2xl bg-white p-6 shadow-sm">
                    <h2 className="font-bold text-stone-900">Needs your attention</h2>
                    {pendingBookings.length === 0 && pendingReviews.length === 0 ? (
                      <p className="mt-3 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800">
                        All caught up — no pending bookings or reviews.
                      </p>
                    ) : (
                      <div className="mt-4 space-y-2">
                        {pendingBookings.slice(0, 3).map((b) => (
                          <button
                            key={b.id}
                            type="button"
                            onClick={() => setTab("bookings")}
                            className="flex w-full items-center justify-between rounded-xl bg-amber-50 px-4 py-3 text-left text-sm transition hover:bg-amber-100"
                          >
                            <span className="font-semibold text-amber-950">
                              {b.name} <span className="font-normal">· {b.villaName || "Any villa"}</span>
                            </span>
                            <span className="text-xs text-amber-700">booking</span>
                          </button>
                        ))}
                        {pendingReviews.slice(0, 3).map((r) => (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => setTab("reviews")}
                            className="flex w-full items-center justify-between rounded-xl bg-sky-50 px-4 py-3 text-left text-sm transition hover:bg-sky-100"
                          >
                            <span className="font-semibold text-sky-950">
                              {r.guestName} <span className="font-normal">· {r.rating}★ review</span>
                            </span>
                            <span className="text-xs text-sky-700">review</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="rounded-2xl bg-stone-950 p-6 text-white shadow-sm">
                    <h2 className="font-bold">Quick actions</h2>
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setFormVilla(null)}
                        className="rounded-xl bg-white/10 px-4 py-3 text-sm font-semibold transition hover:bg-white/20"
                      >
                        + Add villa
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab("gallery")}
                        className="rounded-xl bg-white/10 px-4 py-3 text-sm font-semibold transition hover:bg-white/20"
                      >
                        + Add photo
                      </button>
                      <button
                        type="button"
                        onClick={() => setTab("content")}
                        className="rounded-xl bg-white/10 px-4 py-3 text-sm font-semibold transition hover:bg-white/20"
                      >
                        Edit homepage text
                      </button>
                      <Link
                        href="/"
                        className="rounded-xl bg-amber-400 px-4 py-3 text-center text-sm font-bold text-amber-950 transition hover:bg-amber-300"
                      >
                        Visual edit mode
                      </Link>
                    </div>
                    <p className="mt-4 text-xs leading-relaxed text-stone-400">
                      Tip: open the website while logged in and click the amber “Editing” pill — then
                      click any headline, paragraph or photo to change it right on the page.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {tab === "bookings" && (
              <div className="space-y-3">
                {bookings.length === 0 && (
                  <p className="rounded-2xl bg-white p-10 text-center text-sm text-stone-500 shadow-sm">
                    No booking requests yet. Share your site and they will land here.
                  </p>
                )}
                {bookings.map((b) => (
                  <div key={b.id} className="rounded-2xl bg-white p-5 shadow-sm">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-stone-900">
                          {b.name}{" "}
                          <span className="font-normal text-stone-400">· {b.villaName || "Any villa"}</span>
                        </p>
                        <p className="mt-1 text-sm text-stone-500">
                          {b.email}
                          {b.phone ? ` · ${b.phone}` : ""} · {b.guests} guest{b.guests === 1 ? "" : "s"}
                        </p>
                        <p className="mt-1 text-sm text-stone-500">
                          {[b.checkIn && `in ${b.checkIn}`, b.checkOut && `out ${b.checkOut}`]
                            .filter(Boolean)
                            .join(" → ") || "Flexible dates"}
                        </p>
                        {b.message && (
                          <p className="mt-2 rounded-lg bg-stone-50 p-3 text-sm text-stone-600">“{b.message}”</p>
                        )}
                        <p className="mt-2 text-xs text-stone-400">
                          Received {new Date(b.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <select
                          value={b.status}
                          onChange={(e) => setBookingStatus(b.id, e.target.value)}
                          className={cn(
                            "rounded-full px-3 py-1.5 text-xs font-bold outline-none",
                            STATUS_STYLES[b.status] ?? STATUS_STYLES.pending
                          )}
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirmed</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => deleteBooking(b.id)}
                          title="Delete"
                          className="rounded-full bg-stone-100 p-2 text-stone-500 transition hover:bg-rose-600 hover:text-white"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === "villas" && (
              <div>
                <button
                  type="button"
                  onClick={() => setFormVilla(null)}
                  className="mb-4 flex items-center gap-2 rounded-full bg-stone-950 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-stone-800"
                >
                  <Plus className="h-4 w-4" /> Add villa
                </button>
                <div className="space-y-3">
                  {villas.map((v) => (
                    <div key={v.id} className="flex flex-wrap items-center gap-4 rounded-2xl bg-white p-4 shadow-sm">
                      <div className="relative h-20 w-28 shrink-0 overflow-hidden rounded-xl bg-stone-200">
                        {v.coverImage && (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={v.coverImage} alt={v.name} className="h-full w-full object-cover" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="flex flex-wrap items-center gap-2 font-bold text-stone-900">
                          {v.name}
                          {!v.active && (
                            <span className="rounded-full bg-stone-200 px-2 py-0.5 text-[11px] font-bold text-stone-600">
                              Hidden
                            </span>
                          )}
                          {v.featured && (
                            <span className="rounded-full bg-amber-100 px-2 py-0.5 text-[11px] font-bold text-amber-800">
                              Featured
                            </span>
                          )}
                        </p>
                        <p className="mt-0.5 flex items-center gap-2 text-sm text-stone-500">
                          <BedDouble className="h-4 w-4" /> {v.bedrooms} bd · {v.bathrooms} ba · sleeps{" "}
                          {v.maxGuests} · ${v.pricePerNight}/night
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => toggleVilla(v)}
                          title={v.active ? "Hide from site" : "Show on site"}
                          className="rounded-full bg-stone-100 p-2.5 text-stone-600 transition hover:bg-amber-400 hover:text-amber-950"
                        >
                          {v.active ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                        </button>
                        <button
                          type="button"
                          onClick={() => setFormVilla(v)}
                          title="Edit"
                          className="rounded-full bg-stone-100 p-2.5 text-stone-600 transition hover:bg-amber-400 hover:text-amber-950"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteVilla(v)}
                          title="Delete"
                          className="rounded-full bg-stone-100 p-2.5 text-stone-600 transition hover:bg-rose-600 hover:text-white"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "gallery" && (
              <div>
                <form onSubmit={addPhoto} className="mb-5 rounded-2xl bg-white p-5 shadow-sm">
                  <h2 className="flex items-center gap-2 font-bold text-stone-900">
                    <ImagePlus className="h-5 w-5 text-amber-600" /> Add a photo
                  </h2>
                  <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_200px_160px_auto]">
                    <input
                      value={photoUrl}
                      onChange={(e) => setPhotoUrl(e.target.value)}
                      placeholder="Image URL (https://…)"
                      className="rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500"
                    />
                    <input
                      value={photoCaption}
                      onChange={(e) => setPhotoCaption(e.target.value)}
                      placeholder="Caption"
                      className="rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500"
                    />
                    <input
                      value={photoCategory}
                      onChange={(e) => setPhotoCategory(e.target.value)}
                      placeholder="Category"
                      className="rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500"
                    />
                    <button
                      type="submit"
                      disabled={photoBusy || !photoUrl.trim()}
                      className="flex items-center justify-center gap-2 rounded-lg bg-stone-950 px-5 py-2 text-sm font-semibold text-white disabled:opacity-50"
                    >
                      {photoBusy && <Loader2 className="h-4 w-4 animate-spin" />} Add
                    </button>
                  </div>
                </form>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                  {gallery.map((g) => (
                    <div key={g.id} className="group relative aspect-square overflow-hidden rounded-2xl bg-stone-200">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={g.url} alt={g.caption} className="h-full w-full object-cover" />
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-stone-950/80 to-transparent p-3 pt-8 text-left">
                        <p className="truncate text-xs font-semibold text-white">{g.caption || "Untitled"}</p>
                        <p className="text-[11px] text-stone-300">{g.category}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => deletePhoto(g.id)}
                        title="Delete"
                        className="absolute right-2 top-2 rounded-full bg-white/95 p-2 text-stone-700 opacity-0 shadow transition group-hover:opacity-100 hover:bg-rose-600 hover:text-white"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {tab === "reviews" && (
              <div className="grid gap-4 lg:grid-cols-2">
                {reviews.length === 0 && (
                  <p className="rounded-2xl bg-white p-10 text-center text-sm text-stone-500 shadow-sm lg:col-span-2">
                    No reviews yet.
                  </p>
                )}
                {reviews.map((r) => (
                  <div key={r.id} className="rounded-2xl bg-white p-5 shadow-sm">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold text-stone-900">{r.guestName}</p>
                        <p className="text-xs text-stone-500">
                          {[r.location, r.villaName].filter(Boolean).join(" · ")}
                        </p>
                      </div>
                      {!r.approved ? (
                        <span className="rounded-full bg-amber-100 px-2.5 py-1 text-[11px] font-bold text-amber-800">
                          Pending
                        </span>
                      ) : (
                        <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-bold text-emerald-800">
                          Live
                        </span>
                      )}
                    </div>
                    <Stars rating={r.rating} className="mt-2" />
                    <p className="mt-2 text-sm leading-relaxed text-stone-600">“{r.text}”</p>
                    <div className="mt-3 flex gap-2">
                      {!r.approved && (
                        <button
                          type="button"
                          onClick={() => approveReview(r.id)}
                          className="flex items-center gap-1.5 rounded-full bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white transition hover:bg-emerald-500"
                        >
                          <Check className="h-3.5 w-3.5" /> Publish
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => deleteReview(r.id)}
                        className="flex items-center gap-1.5 rounded-full bg-stone-100 px-4 py-1.5 text-xs font-bold text-stone-600 transition hover:bg-rose-600 hover:text-white"
                      >
                        <Trash2 className="h-3.5 w-3.5" /> Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {tab === "content" && (
              <div className="rounded-2xl bg-white p-6 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="font-bold text-stone-900">Homepage text & images</h2>
                    <p className="text-sm text-stone-500">
                      {dirtyContent.length === 0
                        ? "Everything is saved and live."
                        : `${dirtyContent.length} unsaved change${dirtyContent.length === 1 ? "" : "s"}`}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <input
                      value={contentFilter}
                      onChange={(e) => setContentFilter(e.target.value)}
                      placeholder="Search fields…"
                      className="rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const ok = await saveMany(
                          dirtyContent.map((d) => ({ key: d.key, value: drafts[d.key] ?? "" }))
                        );
                        if (ok) refreshContent();
                      }}
                      disabled={saving || dirtyContent.length === 0}
                      className="flex items-center gap-2 rounded-lg bg-stone-950 px-5 py-2 text-sm font-semibold text-white disabled:opacity-50"
                    >
                      {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                      Save ({dirtyContent.length})
                    </button>
                  </div>
                </div>
                <div className="mt-6 grid gap-8 lg:grid-cols-2">
                  {contentSections.map(([section, defs]) => (
                    <div key={section}>
                      <p className="mb-3 text-xs font-bold uppercase tracking-widest text-amber-700">
                        {section}
                      </p>
                      <div className="space-y-3">
                        {defs.map((def) => {
                          const isDirty = (drafts[def.key] ?? "") !== (content[def.key] ?? "");
                          return (
                            <div key={def.key}>
                              <label className="mb-1 flex items-center gap-2 text-xs font-semibold text-stone-600">
                                {def.label}
                                {isDirty && <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />}
                              </label>
                              {def.type === "textarea" ? (
                                <textarea
                                  value={drafts[def.key] ?? ""}
                                  onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                                  rows={3}
                                  className={cn(
                                    "w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-amber-200",
                                    isDirty ? "border-amber-500" : "border-stone-300"
                                  )}
                                />
                              ) : def.type === "image" ? (
                                <div className="space-y-2">
                                  {drafts[def.key] && (
                                    <div className="aspect-video overflow-hidden rounded-lg bg-stone-100">
                                      {/* eslint-disable-next-line @next/next/no-img-element */}
                                      <img src={drafts[def.key]} alt={def.label} className="h-full w-full object-cover" />
                                    </div>
                                  )}
                                  <input
                                    value={drafts[def.key] ?? ""}
                                    onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                                    className={cn(
                                      "w-full rounded-lg border px-3 py-2 font-mono text-xs outline-none focus:ring-2 focus:ring-amber-200",
                                      isDirty ? "border-amber-500" : "border-stone-300"
                                    )}
                                  />
                                </div>
                              ) : (
                                <input
                                  value={drafts[def.key] ?? ""}
                                  onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                                  className={cn(
                                    "w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-amber-200",
                                    isDirty ? "border-amber-500" : "border-stone-300"
                                  )}
                                />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {formVilla !== undefined && (
        <VillaFormModal
          villa={formVilla}
          onClose={() => setFormVilla(undefined)}
          onSaved={refreshAll}
        />
      )}
    </div>
  );
}
