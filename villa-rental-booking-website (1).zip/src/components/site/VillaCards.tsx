"use client";

import { useState } from "react";
import Image from "next/image";
import {
  ArrowRight,
  Bath,
  BedDouble,
  Check,
  Eye,
  EyeOff,
  Maximize,
  Pencil,
  Trash2,
  Users,
  X,
} from "lucide-react";
import type { Villa } from "@/db/schema";
import { cn } from "@/lib/cn";

export function VillaCard({
  villa,
  onView,
  onEdit,
  onDelete,
  onToggleActive,
  showAdmin,
}: {
  villa: Villa;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onToggleActive: () => void;
  showAdmin: boolean;
}) {
  return (
    <article
      className={cn(
        "group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-[0_10px_40px_rgba(0,0,0,0.08)] transition-all hover:-translate-y-1 hover:shadow-[0_24px_60px_rgba(0,0,0,0.14)]",
        !villa.active && "opacity-75"
      )}
    >
      <button type="button" onClick={onView} className="relative block aspect-[4/3] overflow-hidden text-left">
        {villa.coverImage ? (
          <Image
            src={villa.coverImage}
            alt={villa.name}
            fill
            sizes="(max-width: 768px) 100vw, 33vw"
            className="object-cover transition-transform duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="absolute inset-0 bg-stone-200" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-stone-950/50 via-transparent to-transparent" />
        {villa.featured && (
          <span className="absolute left-4 top-4 rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-amber-950">
            Featured
          </span>
        )}
        {!villa.active && (
          <span className="absolute left-4 top-4 rounded-full bg-stone-900 px-3 py-1 text-xs font-bold text-white">
            Hidden
          </span>
        )}
        <span className="absolute bottom-4 left-4 rounded-full bg-white/95 px-3 py-1.5 text-sm font-bold text-stone-900">
          ${villa.pricePerNight}
          <span className="font-normal text-stone-500"> / night</span>
        </span>
      </button>

      {showAdmin && (
        <div className="absolute right-3 top-3 flex gap-1.5">
          <button
            type="button"
            onClick={onEdit}
            title="Edit villa"
            className="rounded-full bg-white/95 p-2 text-stone-700 shadow transition hover:bg-amber-400 hover:text-amber-950"
          >
            <Pencil className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={onToggleActive}
            title={villa.active ? "Hide villa" : "Show villa"}
            className="rounded-full bg-white/95 p-2 text-stone-700 shadow transition hover:bg-amber-400 hover:text-amber-950"
          >
            {villa.active ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          </button>
          <button
            type="button"
            onClick={onDelete}
            title="Delete villa"
            className="rounded-full bg-white/95 p-2 text-stone-700 shadow transition hover:bg-rose-600 hover:text-white"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )}

      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-display text-2xl font-semibold text-stone-900">{villa.name}</h3>
        <p className="mt-1 text-sm text-stone-500">{villa.tagline}</p>
        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-2 text-sm text-stone-600">
          <span className="flex items-center gap-1.5">
            <Users className="h-4 w-4 text-amber-600" /> {villa.maxGuests} guests
          </span>
          <span className="flex items-center gap-1.5">
            <BedDouble className="h-4 w-4 text-amber-600" /> {villa.bedrooms} bd
          </span>
          <span className="flex items-center gap-1.5">
            <Bath className="h-4 w-4 text-amber-600" /> {villa.bathrooms} ba
          </span>
          {villa.sizeSqm > 0 && (
            <span className="flex items-center gap-1.5">
              <Maximize className="h-4 w-4 text-amber-600" /> {villa.sizeSqm} m²
            </span>
          )}
        </div>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {villa.amenities.slice(0, 4).map((a) => (
            <span key={a} className="rounded-full bg-stone-100 px-2.5 py-1 text-xs text-stone-600">
              {a}
            </span>
          ))}
          {villa.amenities.length > 4 && (
            <span className="rounded-full bg-stone-100 px-2.5 py-1 text-xs font-semibold text-stone-600">
              +{villa.amenities.length - 4} more
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={onView}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-amber-500 hover:text-amber-950"
        >
          View details <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </article>
  );
}

export function VillaModal({
  villa,
  onClose,
  onBook,
}: {
  villa: Villa;
  onClose: () => void;
  onBook: (villa: Villa) => void;
}) {
  const photos = villa.images.length > 0 ? villa.images : villa.coverImage ? [villa.coverImage] : [];
  const [active, setActive] = useState(0);
  return (
    <div
      className="fixed inset-0 z-[75] overflow-y-auto bg-stone-950/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="mx-auto my-8 w-full max-w-4xl overflow-hidden rounded-3xl bg-white shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative aspect-[16/8] bg-stone-200">
          {photos[active] ? (
            <Image src={photos[active]} alt={villa.name} fill sizes="100vw" className="object-cover" />
          ) : null}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950/60 to-transparent" />
          <button
            type="button"
            onClick={onClose}
            className="absolute right-4 top-4 rounded-full bg-white/95 p-2 text-stone-800 shadow transition hover:bg-white"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="absolute bottom-4 left-6 right-6">
            <p className="text-sm font-medium text-amber-300">{villa.tagline}</p>
            <h3 className="font-display text-3xl font-semibold text-white sm:text-4xl">{villa.name}</h3>
          </div>
        </div>

        {photos.length > 1 && (
          <div className="flex gap-2 overflow-x-auto border-b border-stone-100 px-6 py-3">
            {photos.map((p, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActive(i)}
                className={cn(
                  "relative h-16 w-24 shrink-0 overflow-hidden rounded-lg border-2",
                  i === active ? "border-amber-500" : "border-transparent opacity-70 hover:opacity-100"
                )}
              >
                <Image src={p} alt="" fill sizes="100px" className="object-cover" />
              </button>
            ))}
          </div>
        )}

        <div className="grid gap-8 p-6 sm:grid-cols-[1fr_280px] sm:p-8">
          <div>
            <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm font-medium text-stone-700">
              <span className="flex items-center gap-1.5"><Users className="h-4 w-4 text-amber-600" /> Up to {villa.maxGuests} guests</span>
              <span className="flex items-center gap-1.5"><BedDouble className="h-4 w-4 text-amber-600" /> {villa.bedrooms} bedrooms</span>
              <span className="flex items-center gap-1.5"><Bath className="h-4 w-4 text-amber-600" /> {villa.bathrooms} bathrooms</span>
              {villa.sizeSqm > 0 && (
                <span className="flex items-center gap-1.5"><Maximize className="h-4 w-4 text-amber-600" /> {villa.sizeSqm} m²</span>
              )}
            </div>
            <p className="mt-4 leading-relaxed text-stone-600">{villa.description}</p>
            <h4 className="mt-6 text-sm font-bold uppercase tracking-widest text-stone-500">Amenities</h4>
            <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {villa.amenities.map((a) => (
                <li key={a} className="flex items-center gap-2 text-sm text-stone-700">
                  <span className="rounded-full bg-emerald-100 p-1 text-emerald-700"><Check className="h-3 w-3" /></span>
                  {a}
                </li>
              ))}
            </ul>
          </div>
          <div className="h-fit rounded-2xl bg-stone-50 p-5">
            <p className="text-sm text-stone-500">From</p>
            <p className="font-display text-4xl font-semibold text-stone-900">
              ${villa.pricePerNight}
              <span className="text-base font-normal text-stone-500"> / night</span>
            </p>
            <button
              type="button"
              onClick={() => onBook(villa)}
              className="mt-4 w-full rounded-xl bg-amber-400 px-4 py-3 text-sm font-bold text-amber-950 transition hover:bg-amber-300"
            >
              Request to book
            </button>
            <p className="mt-3 text-center text-xs text-stone-400">
              Free cancellation · No payment today
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
