"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  Clock,
  Home,
  Mail,
  MapPin,
  Menu,
  Phone,
  Plus,
  ShieldCheck,
  Sparkles,
  Star,
  Tv,
  UtensilsCrossed,
  Wifi,
  X,
} from "lucide-react";
import type { GalleryImage, Testimonial, Villa } from "@/db/schema";
import { EditProvider, useEdit } from "../edit/EditContext";
import { EditableImage } from "../edit/EditableImage";
import { EditableText } from "../edit/EditableText";
import { EditToolbar } from "../edit/EditToolbar";
import { BookingForm } from "./BookingForm";
import { GallerySection } from "./GallerySection";
import { ReviewsSection } from "./ReviewsSection";
import { VillaCard, VillaModal } from "./VillaCards";
import { VillaFormModal } from "./VillaFormModal";
import { cn } from "@/lib/cn";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

const EXPERIENCE = [
  { icon: Home, title: "Modern designer interiors", text: "Clean lines, natural materials and light-filled rooms — styled for slow mornings." },
  { icon: UtensilsCrossed, title: "Full modern kitchen", text: "Cook properly: induction hob, big fridge, espresso machine and all the essentials." },
  { icon: Sparkles, title: "Daily housekeeping", text: "Fresh towels, made beds and spotless bathrooms — every single day of your stay." },
  { icon: Wifi, title: "Fast fibre Wi-Fi", text: "300 Mbps in every room, plus proper work desks for remote-work days." },
  { icon: Tv, title: "Smart TV & streaming", text: "Big smart TVs with Netflix ready in the living room and the master suite." },
  { icon: Phone, title: "Local host on call", text: "Airport pickup, surf rental, restaurant tips — one message away, 7 AM to 10 PM." },
];

function Navbar({ onBook }: { onBook: () => void }) {
  const { t } = useEdit();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { href: "#villas", label: "Villas" },
    { href: "#experience", label: "Experience" },
    { href: "#gallery", label: "Gallery" },
    { href: "#reviews", label: "Reviews" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-[60] transition-all",
        scrolled ? "bg-stone-950/90 shadow-lg backdrop-blur" : "bg-gradient-to-b from-stone-950/70 to-transparent"
      )}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-8">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-amber-400 font-display text-xl font-bold text-amber-950">
            {t("site.name").charAt(0) || "A"}
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg font-semibold text-white">
              <EditableText k="site.name" />
            </span>
            <span className="block text-[11px] uppercase tracking-widest text-amber-300">
              <EditableText k="site.tagline" />
            </span>
          </span>
        </a>
        <div className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-sm font-medium text-stone-200 transition hover:text-amber-300">
              {l.label}
            </a>
          ))}
          <button
            type="button"
            onClick={onBook}
            className="rounded-full bg-amber-400 px-6 py-2.5 text-sm font-bold text-amber-950 transition hover:bg-amber-300"
          >
            <EditableText k="hero.cta_primary" />
          </button>
        </div>
        <button
          type="button"
          onClick={() => setOpen(!open)}
          className="rounded-full p-2 text-white transition hover:bg-white/10 lg:hidden"
          aria-label="Menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>
      {open && (
        <div className="border-t border-white/10 bg-stone-950/95 px-5 pb-6 pt-2 backdrop-blur lg:hidden">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block border-b border-white/5 py-3 text-sm font-medium text-stone-200"
            >
              {l.label}
            </a>
          ))}
          <button
            type="button"
            onClick={() => {
              setOpen(false);
              onBook();
            }}
            className="mt-4 w-full rounded-xl bg-amber-400 px-6 py-3 text-sm font-bold text-amber-950"
          >
            {t("hero.cta_primary")}
          </button>
        </div>
      )}
    </header>
  );
}

function Hero({ onBook, onExplore }: { onBook: () => void; onExplore: () => void }) {
  const { t } = useEdit();
  return (
    <section id="top" className="relative flex min-h-[100svh] items-end">
      <div className="absolute inset-0">
        <EditableImage k="hero.image" alt="Villa at sunset" className="h-full w-full" priority />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/35 to-stone-950/30" />
      </div>

      <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-36 sm:px-8">
        <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-amber-300">
          <MapPin className="h-4 w-4" />
          <EditableText k="hero.eyebrow" />
        </p>
        <h1 className="mt-4 max-w-3xl font-display text-5xl font-semibold leading-[1.02] text-white sm:text-7xl">
          <EditableText k="hero.title" as="span" />
        </h1>
        <p className="mt-5 max-w-xl text-lg leading-relaxed text-stone-200">
          <EditableText k="hero.subtitle" as="span" multiline />
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={onBook}
            className="group flex items-center gap-2 rounded-full bg-amber-400 px-8 py-4 text-sm font-bold text-amber-950 transition hover:bg-amber-300"
          >
            <EditableText k="hero.cta_primary" />
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </button>
          <button
            type="button"
            onClick={onExplore}
            className="rounded-full border border-white/30 bg-white/10 px-8 py-4 text-sm font-bold text-white backdrop-blur transition hover:bg-white/20"
          >
            <EditableText k="hero.cta_secondary" />
          </button>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { v: "stats.villas", suffix: "", label: "private villas" },
            { v: "stats.guests", suffix: "", label: "happy guests" },
            { v: "stats.rating", suffix: "★", label: "average rating" },
            { v: "stats.years", suffix: "", label: "years hosting" },
          ].map((s) => (
            <div key={s.v} className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur">
              <p className="font-display text-3xl font-semibold text-white">
                <EditableText k={s.v} />
                {s.suffix && <span className="text-amber-300">{s.suffix}</span>}
              </p>
              <p className="mt-1 text-xs uppercase tracking-widest text-stone-300">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SectionHeader({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-700">
        <EditableText k={eyebrow} />
      </p>
      <h2 className="mt-3 font-display text-4xl font-semibold text-stone-900 sm:text-5xl">
        <EditableText k={title} as="span" />
      </h2>
      <p className="mt-4 leading-relaxed text-stone-500">
        <EditableText k={subtitle} as="span" multiline />
      </p>
    </div>
  );
}

function SiteInner({
  initialVillas,
  initialGallery,
  initialReviews,
}: {
  initialVillas: Villa[];
  initialGallery: GalleryImage[];
  initialReviews: Testimonial[];
}) {
  const { isAdmin, editMode, t, toast } = useEdit();
  const [villas, setVillas] = useState(initialVillas);
  const [gallery, setGallery] = useState(initialGallery);
  const [reviews, setReviews] = useState(initialReviews);
  const [viewing, setViewing] = useState<Villa | null>(null);
  const [formVilla, setFormVilla] = useState<Villa | null | undefined>(undefined);
  const [bookVillaId, setBookVillaId] = useState<number | null>(null);

  const refreshVillas = useCallback(async () => {
    try {
      const res = await apiFetch("/api/villas", { cache: "no-store" });
      const data = await res.json();
      if (data.villas) setVillas(data.villas);
    } catch {
      /* keep current */
    }
  }, []);

  const refreshGallery = useCallback(async () => {
    try {
      const res = await apiFetch("/api/gallery", { cache: "no-store" });
      const data = await res.json();
      if (data.gallery) setGallery(data.gallery);
    } catch {
      /* keep current */
    }
  }, []);

  const refreshReviews = useCallback(async () => {
    try {
      const url = isAdmin ? "/api/testimonials?all=1" : "/api/testimonials";
      const res = await apiFetch(url, { cache: "no-store" });
      const data = await res.json();
      if (data.testimonials) setReviews(data.testimonials);
    } catch {
      /* keep current */
    }
  }, [isAdmin]);

  useEffect(() => {
    refreshReviews();
  }, [refreshReviews]);

  const showAdmin = isAdmin && editMode;
  const visibleVillas = showAdmin ? villas : villas.filter((v) => v.active);
  const visibleReviews = showAdmin ? reviews : reviews.filter((r) => r.approved);

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  const handleBook = (villa: Villa) => {
    setViewing(null);
    setBookVillaId(villa.id);
    scrollTo("booking");
    toast(`Booking ${villa.name} — pick your dates below`, "info");
  };

  const deleteVilla = async (villa: Villa) => {
    if (!confirm(`Delete ${villa.name}? This cannot be undone.`)) return;
    const res = await apiFetch(`/api/villas/${villa.id}`, { method: "DELETE" });
    if (res.ok) {
      toast("Villa deleted", "success");
      refreshVillas();
    } else toast("Could not delete", "error");
  };

  const toggleVilla = async (villa: Villa) => {
    const res = await apiFetch(`/api/villas/${villa.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !villa.active }),
    });
    if (res.ok) {
      toast(villa.active ? `${villa.name} hidden` : `${villa.name} is live`, "success");
      refreshVillas();
    } else {
      toast(await apiErrorMessage(res, "Could not update villa"), "error");
    }
  };

  return (
    <div className="min-h-screen bg-stone-50">
      <Navbar onBook={() => scrollTo("booking")} />
      <Hero onBook={() => scrollTo("booking")} onExplore={() => scrollTo("villas")} />

      {/* Villas */}
      <section id="villas" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-20 sm:px-8 sm:py-28">
        <SectionHeader eyebrow="villas.eyebrow" title="villas.title" subtitle="villas.subtitle" />
        {showAdmin && (
          <div className="mt-8 flex justify-center">
            <button
              type="button"
              onClick={() => setFormVilla(null)}
              className="flex items-center gap-2 rounded-full bg-amber-400 px-6 py-3 text-sm font-bold text-amber-950 shadow-lg transition hover:bg-amber-300"
            >
              <Plus className="h-4 w-4" /> Add a villa
            </button>
          </div>
        )}
        <div className="mt-10 grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {visibleVillas.map((v) => (
            <VillaCard
              key={v.id}
              villa={v}
              showAdmin={showAdmin}
              onView={() => setViewing(v)}
              onEdit={() => setFormVilla(v)}
              onDelete={() => deleteVilla(v)}
              onToggleActive={() => toggleVilla(v)}
            />
          ))}
        </div>
        {visibleVillas.length === 0 && (
          <p className="mt-10 rounded-2xl bg-white p-8 text-center text-sm text-stone-500 shadow">
            No villas to show right now.
          </p>
        )}
      </section>

      {/* Experience */}
      <section id="experience" className="scroll-mt-20 bg-stone-950 py-20 sm:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-2">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
              <EditableText k="experience.eyebrow" />
            </p>
            <h2 className="mt-3 font-display text-4xl font-semibold text-white sm:text-5xl">
              <EditableText k="experience.title" as="span" />
            </h2>
            <p className="mt-4 leading-relaxed text-stone-400">
              <EditableText k="experience.subtitle" as="span" multiline />
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {EXPERIENCE.map((f) => (
                <div key={f.title} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                  <span className="grid h-11 w-11 place-items-center rounded-xl bg-amber-400/15 text-amber-300">
                    <f.icon className="h-5 w-5" />
                  </span>
                  <h3 className="mt-3 font-semibold text-white">{f.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-stone-400">{f.text}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <EditableImage
              k="experience.image"
              alt="Terrace dinner at the villa"
              className="aspect-[4/5] rounded-3xl shadow-2xl"
            />
            <div className="absolute -bottom-6 -left-4 rounded-2xl bg-amber-400 p-5 shadow-xl sm:-left-6">
              <p className="flex items-center gap-1.5 font-display text-3xl font-semibold text-amber-950">
                {t("stats.rating") || "4.98"} <Star className="h-6 w-6 fill-amber-950" />
              </p>
              <p className="text-xs font-bold uppercase tracking-widest text-amber-900">
                from {t("stats.guests") || "12k+"} verified stays
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section id="gallery" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-20 sm:px-8 sm:py-28">
        <SectionHeader eyebrow="gallery.eyebrow" title="gallery.title" subtitle="gallery.subtitle" />
        <div className="mt-10">
          <GallerySection images={gallery} onChanged={refreshGallery} />
        </div>
      </section>

      {/* Reviews */}
      <section id="reviews" className="scroll-mt-20 bg-amber-50/60 py-20 sm:py-28">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <SectionHeader eyebrow="reviews.eyebrow" title="reviews.title" subtitle="reviews.subtitle" />
          <div className="mt-10">
            <ReviewsSection reviews={visibleReviews} villas={villas} onChanged={refreshReviews} />
          </div>
        </div>
      </section>

      {/* Booking */}
      <section id="booking" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-20 sm:px-8 sm:py-28">
        <SectionHeader eyebrow="booking.eyebrow" title="booking.title" subtitle="booking.subtitle" />
        <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_1.2fr]">
          <div className="flex flex-col gap-5">
            <div className="rounded-3xl bg-stone-950 p-8 text-white">
              <h3 className="font-display text-2xl font-semibold">Why book direct?</h3>
              <ul className="mt-5 space-y-4 text-sm">
                <li className="flex gap-3">
                  <BadgeCheck className="h-5 w-5 shrink-0 text-amber-400" />
                  <span><strong>Best-rate promise</strong> — 10% below any listing site, always.</span>
                </li>
                <li className="flex gap-3">
                  <ShieldCheck className="h-5 w-5 shrink-0 text-amber-400" />
                  <span><strong>Free cancellation</strong> up to 7 days before check-in.</span>
                </li>
                <li className="flex gap-3">
                  <Sparkles className="h-5 w-5 shrink-0 text-amber-400" />
                  <span><strong>Welcome hamper</strong> — fresh tropical fruit, local coffee & late checkout on us.</span>
                </li>
              </ul>
              <div className="mt-6 border-t border-white/10 pt-6 text-sm text-stone-300">
                <p className="flex items-center gap-2"><Phone className="h-4 w-4 text-amber-400" /><EditableText k="contact.phone" /></p>
                <p className="mt-2 flex items-center gap-2"><Mail className="h-4 w-4 text-amber-400" /><EditableText k="contact.email" /></p>
                <p className="mt-2 flex items-center gap-2"><Clock className="h-4 w-4 text-amber-400" /><EditableText k="contact.hours" /></p>
              </div>
            </div>
            <div className="rounded-3xl border border-stone-200 bg-white p-8">
              <h3 className="flex items-center gap-2 font-display text-2xl font-semibold text-stone-900">
                <MapPin className="h-5 w-5 text-amber-600" /> Finding us
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-stone-600">
                <EditableText k="contact.address" as="span" />
              </p>
              <p className="mt-3 text-sm text-stone-500">
                25 minutes from Ngurah Rai Airport · 5 minutes to Suluban surf beach · 10 minutes to Uluwatu Temple.
              </p>
            </div>
          </div>
          <BookingForm villas={villas} preselectedId={bookVillaId} />
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="scroll-mt-20 bg-stone-950 pb-28 pt-14 text-stone-400">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 sm:px-8 md:grid-cols-3">
          <div>
            <p className="font-display text-2xl font-semibold text-white">{t("site.name")}</p>
            <p className="mt-1 text-sm">{t("site.tagline")}</p>
            <p className="mt-4 text-sm leading-relaxed">{t("contact.address")}</p>
          </div>
          <div className="text-sm">
            <p className="font-bold uppercase tracking-widest text-stone-500">Explore</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a href="#villas" className="transition hover:text-amber-300">Villas</a>
              <a href="#experience" className="transition hover:text-amber-300">Experience</a>
              <a href="#gallery" className="transition hover:text-amber-300">Gallery</a>
              <a href="#reviews" className="transition hover:text-amber-300">Reviews</a>
              <a href="#booking" className="transition hover:text-amber-300">Book now</a>
            </div>
          </div>
          <div className="text-sm">
            <p className="font-bold uppercase tracking-widest text-stone-500">Contact</p>
            <p className="mt-3">{t("contact.phone")}</p>
            <p className="mt-1">{t("contact.email")}</p>
            <p className="mt-1">{t("contact.hours")}</p>
          </div>
        </div>
        <div className="mx-auto mt-10 max-w-7xl border-t border-white/10 px-5 pt-6 text-center text-xs sm:px-8">
          <EditableText k="footer.note" />
        </div>
      </footer>

      {viewing && (
        <VillaModal villa={viewing} onClose={() => setViewing(null)} onBook={handleBook} />
      )}
      {formVilla !== undefined && (
        <VillaFormModal
          villa={formVilla}
          onClose={() => setFormVilla(undefined)}
          onSaved={refreshVillas}
        />
      )}
      <EditToolbar />
    </div>
  );
}

export function VillaSite(props: {
  initialContent: Record<string, string>;
  initialIsAdmin: boolean;
  initialVillas: Villa[];
  initialGallery: GalleryImage[];
  initialReviews: Testimonial[];
}) {
  return (
    <EditProvider initialContent={props.initialContent} initialIsAdmin={props.initialIsAdmin}>
      <SiteInner
        initialVillas={props.initialVillas}
        initialGallery={props.initialGallery}
        initialReviews={props.initialReviews}
      />
    </EditProvider>
  );
}
