"use client";

import { useState } from "react";
import { Loader2, X } from "lucide-react";
import type { Villa } from "@/db/schema";
import { useEdit } from "../edit/EditContext";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

const EMPTY = {
  name: "",
  tagline: "",
  description: "",
  pricePerNight: 500,
  bedrooms: 3,
  bathrooms: 3,
  maxGuests: 6,
  sizeSqm: 400,
  coverImage: "",
  imagesText: "",
  amenitiesText: "",
  featured: true,
  active: true,
  sortOrder: 0,
};

/** Admin form to add or edit a villa. Used on the homepage and in the dashboard. */
export function VillaFormModal({
  villa,
  onClose,
  onSaved,
}: {
  villa: Villa | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useEdit();
  const [form, setForm] = useState({
    name: villa?.name ?? "",
    tagline: villa?.tagline ?? "",
    description: villa?.description ?? "",
    pricePerNight: villa?.pricePerNight ?? 500,
    bedrooms: villa?.bedrooms ?? 3,
    bathrooms: villa?.bathrooms ?? 3,
    maxGuests: villa?.maxGuests ?? 6,
    sizeSqm: villa?.sizeSqm ?? 400,
    coverImage: villa?.coverImage ?? "",
    imagesText: villa ? villa.images.join("\n") : "",
    amenitiesText: villa ? villa.amenities.join(", ") : "",
    featured: villa?.featured ?? true,
    active: villa?.active ?? true,
    sortOrder: villa?.sortOrder ?? 0,
  });
  const [saving, setSaving] = useState(false);

  const set = (key: keyof typeof EMPTY, value: string | number | boolean) =>
    setForm((p) => ({ ...p, [key]: value }));

  const inputCls =
    "w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200";
  const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-stone-500";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast("Give the villa a name first", "error");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        tagline: form.tagline.trim(),
        description: form.description.trim(),
        pricePerNight: Number(form.pricePerNight) || 0,
        bedrooms: Number(form.bedrooms) || 1,
        bathrooms: Number(form.bathrooms) || 1,
        maxGuests: Number(form.maxGuests) || 2,
        sizeSqm: Number(form.sizeSqm) || 0,
        coverImage: form.coverImage.trim(),
        images: form.imagesText.split("\n").map((s) => s.trim()).filter(Boolean),
        amenities: form.amenitiesText.split(",").map((s) => s.trim()).filter(Boolean),
        featured: form.featured,
        active: form.active,
        sortOrder: Number(form.sortOrder) || 0,
      };
      const res = await apiFetch(villa ? `/api/villas/${villa.id}` : "/api/villas", {
        method: villa ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(await apiErrorMessage(res, "Could not save villa"));
      toast(villa ? "Villa updated ✓" : "Villa added ✓", "success");
      onSaved();
      onClose();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Could not save villa", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[88] overflow-y-auto bg-stone-950/70 p-4 backdrop-blur-sm" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="mx-auto my-6 w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl"
      >
        <div className="mb-5 flex items-center justify-between">
          <h3 className="text-lg font-bold text-stone-900">{villa ? `Edit ${villa.name}` : "Add a villa"}</h3>
          <button type="button" onClick={onClose} className="rounded-full p-1.5 text-stone-500 hover:bg-stone-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className={labelCls}>Villa name *</label>
            <input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Villa Ocean" className={inputCls} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Tagline</label>
            <input value={form.tagline} onChange={(e) => set("tagline", e.target.value)} placeholder="Modern 2-bedroom near the beach…" className={inputCls} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Description</label>
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={4} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Price / night (USD)</label>
            <input type="number" min={0} value={form.pricePerNight} onChange={(e) => set("pricePerNight", e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Size (m²)</label>
            <input type="number" min={0} value={form.sizeSqm} onChange={(e) => set("sizeSqm", e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Bedrooms</label>
            <input type="number" min={1} value={form.bedrooms} onChange={(e) => set("bedrooms", e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Bathrooms</label>
            <input type="number" min={1} value={form.bathrooms} onChange={(e) => set("bathrooms", e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Max guests</label>
            <input type="number" min={1} value={form.maxGuests} onChange={(e) => set("maxGuests", e.target.value)} className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Sort order</label>
            <input type="number" value={form.sortOrder} onChange={(e) => set("sortOrder", e.target.value)} className={inputCls} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Cover image URL</label>
            <input value={form.coverImage} onChange={(e) => set("coverImage", e.target.value)} placeholder="https://…" className={inputCls} />
            {form.coverImage && (
              <div className="relative mt-2 aspect-[16/7] overflow-hidden rounded-lg bg-stone-100">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={form.coverImage} alt="Cover preview" className="h-full w-full object-cover" />
              </div>
            )}
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>More photos (one URL per line)</label>
            <textarea value={form.imagesText} onChange={(e) => set("imagesText", e.target.value)} rows={3} placeholder="https://…" className={`${inputCls} font-mono text-xs`} />
          </div>
          <div className="sm:col-span-2">
            <label className={labelCls}>Amenities (comma separated)</label>
            <input value={form.amenitiesText} onChange={(e) => set("amenitiesText", e.target.value)} placeholder="Fast Wi-Fi, Full kitchen, Smart TV, …" className={inputCls} />
          </div>
          <label className="flex cursor-pointer items-center gap-2 text-sm font-medium text-stone-700">
            <input type="checkbox" checked={form.featured} onChange={(e) => set("featured", e.target.checked)} className="h-4 w-4 accent-amber-500" />
            Featured badge
          </label>
          <label className="flex cursor-pointer items-center gap-2 text-sm font-medium text-stone-700">
            <input type="checkbox" checked={form.active} onChange={(e) => set("active", e.target.checked)} className="h-4 w-4 accent-amber-500" />
            Visible on site
          </label>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-stone-800 disabled:opacity-50"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          {villa ? "Save changes" : "Add villa"}
        </button>
      </form>
    </div>
  );
}
