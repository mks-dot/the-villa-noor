"use client";

import { useState } from "react";
import { Check, Loader2, PenLine, Star, Trash2, X } from "lucide-react";
import type { Testimonial, Villa } from "@/db/schema";
import { useEdit } from "../edit/EditContext";
import { cn } from "@/lib/cn";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

export function Stars({ rating, className }: { rating: number; className?: string }) {
  return (
    <span className={cn("flex gap-0.5", className)}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={cn("h-4 w-4", i <= rating ? "fill-amber-400 text-amber-400" : "fill-stone-200 text-stone-200")}
        />
      ))}
    </span>
  );
}

export function ReviewsSection({
  reviews,
  villas,
  onChanged,
}: {
  reviews: Testimonial[];
  villas: Villa[];
  onChanged: () => void;
}) {
  const { isAdmin, editMode, toast } = useEdit();
  const [formOpen, setFormOpen] = useState(false);
  const [guestName, setGuestName] = useState("");
  const [location, setLocation] = useState("");
  const [villaName, setVillaName] = useState("");
  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const showAdmin = isAdmin && editMode;

  const inputCls =
    "w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200";
  const labelCls = "mb-1 block text-xs font-semibold uppercase tracking-wide text-stone-500";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guestName.trim() || !text.trim()) {
      toast("Please add your name and review", "error");
      return;
    }
    setSending(true);
    try {
      const res = await apiFetch("/api/testimonials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ guestName: guestName.trim(), location: location.trim(), villaName, rating, text: text.trim() }),
      });
      if (!res.ok) throw new Error(await apiErrorMessage(res, "Could not submit review"));
      toast("Thanks! Your review is awaiting approval", "success");
      setGuestName("");
      setLocation("");
      setVillaName("");
      setRating(5);
      setText("");
      setFormOpen(false);
      onChanged();
    } catch (err) {
      toast(err instanceof Error ? err.message : "Could not submit review", "error");
    } finally {
      setSending(false);
    }
  };

  const approve = async (id: number) => {
    const res = await apiFetch(`/api/testimonials/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ approved: true }),
    });
    if (res.ok) {
      toast("Review approved", "success");
      onChanged();
    } else {
      toast(await apiErrorMessage(res, "Could not approve review"), "error");
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this review?")) return;
    const res = await apiFetch(`/api/testimonials/${id}`, { method: "DELETE" });
    if (res.ok) {
      toast("Review deleted", "success");
      onChanged();
    }
  };

  return (
    <div>
      {reviews.length === 0 ? (
        <p className="rounded-2xl bg-white p-8 text-center text-sm text-stone-500 shadow">
          No reviews yet — be the first to share your stay.
        </p>
      ) : (
        <div className="grid gap-5 md:grid-cols-3">
          {reviews.map((r) => (
            <figure key={r.id} className="relative flex flex-col rounded-3xl bg-white p-6 shadow-[0_10px_40px_rgba(0,0,0,0.06)]">
              {showAdmin && (
                <div className="absolute right-3 top-3 flex gap-1.5">
                  {!r.approved && (
                    <button
                      type="button"
                      onClick={() => approve(r.id)}
                      title="Approve"
                      className="rounded-full bg-emerald-100 p-2 text-emerald-700 transition hover:bg-emerald-600 hover:text-white"
                    >
                      <Check className="h-4 w-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => remove(r.id)}
                    title="Delete"
                    className="rounded-full bg-stone-100 p-2 text-stone-600 transition hover:bg-rose-600 hover:text-white"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              )}
              {!r.approved && <span className="mb-2 w-fit rounded-full bg-amber-100 px-2.5 py-1 text-xs font-bold text-amber-800">Pending approval</span>}
              <Stars rating={r.rating} />
              <blockquote className="mt-3 flex-1 text-[15px] leading-relaxed text-stone-700">
                “{r.text}”
              </blockquote>
              <figcaption className="mt-4 border-t border-stone-100 pt-4">
                <p className="text-sm font-bold text-stone-900">{r.guestName}</p>
                <p className="text-xs text-stone-500">
                  {[r.location, r.villaName, r.stayDate].filter(Boolean).join(" · ")}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      )}

      <div className="mt-6 text-center">
        <button
          type="button"
          onClick={() => setFormOpen(true)}
          className="inline-flex items-center gap-2 rounded-full border border-stone-300 bg-white px-6 py-3 text-sm font-semibold text-stone-700 shadow-sm transition hover:border-amber-500 hover:text-amber-800"
        >
          <PenLine className="h-4 w-4" /> Stayed with us? Leave a review
        </button>
      </div>

      {formOpen && (
        <div className="fixed inset-0 z-[88] grid place-items-center overflow-y-auto bg-stone-950/70 p-4" onClick={() => setFormOpen(false)}>
          <form
            onSubmit={submit}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
          >
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-stone-900">Share your stay</h3>
              <button type="button" onClick={() => setFormOpen(false)} className="rounded-full p-1.5 text-stone-500 hover:bg-stone-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="grid gap-3">
              <div>
                <label className={labelCls}>Your name *</label>
                <input value={guestName} onChange={(e) => setGuestName(e.target.value)} placeholder="Jane Appleseed" className={inputCls} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Where from</label>
                  <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Berlin, Germany" className={inputCls} />
                </div>
                <div>
                  <label className={labelCls}>Villa</label>
                  <select value={villaName} onChange={(e) => setVillaName(e.target.value)} className={inputCls}>
                    <option value="">Select…</option>
                    {villas.map((v) => (
                      <option key={v.id} value={v.name}>{v.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className={labelCls}>Rating</label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <button key={i} type="button" onClick={() => setRating(i)} className="p-0.5">
                      <Star className={cn("h-7 w-7", i <= rating ? "fill-amber-400 text-amber-400" : "fill-stone-200 text-stone-200")} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className={labelCls}>Your review *</label>
                <textarea value={text} onChange={(e) => setText(e.target.value)} rows={4} placeholder="What made your stay special?" className={inputCls} />
              </div>
            </div>
            <button
              type="submit"
              disabled={sending}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50"
            >
              {sending && <Loader2 className="h-4 w-4 animate-spin" />} Submit review
            </button>
            {!isAdmin && <p className="mt-2 text-center text-xs text-stone-400">Reviews appear after approval by our team.</p>}
          </form>
        </div>
      )}
    </div>
  );
}
