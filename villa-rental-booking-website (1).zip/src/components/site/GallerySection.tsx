"use client";

import { useState } from "react";
import Image from "next/image";
import { ChevronLeft, ChevronRight, ImagePlus, Loader2, Trash2, X } from "lucide-react";
import type { GalleryImage } from "@/db/schema";
import { useEdit } from "../edit/EditContext";
import { cn } from "@/lib/cn";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

export function GallerySection({
  images,
  onChanged,
}: {
  images: GalleryImage[];
  onChanged: () => void;
}) {
  const { isAdmin, editMode, toast } = useEdit();
  const [lightbox, setLightbox] = useState<number | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [url, setUrl] = useState("");
  const [caption, setCaption] = useState("");
  const [category, setCategory] = useState("Villa");
  const [saving, setSaving] = useState(false);

  const showAdmin = isAdmin && editMode;

  const remove = async (id: number) => {
    if (!confirm("Delete this photo?")) return;
    const res = await apiFetch(`/api/gallery/${id}`, { method: "DELETE" });
    if (res.ok) {
      toast("Photo deleted", "success");
      onChanged();
    } else toast(await apiErrorMessage(res, "Could not delete"), "error");
  };

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setSaving(true);
    try {
      const res = await apiFetch("/api/gallery", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim(), caption: caption.trim(), category, sortOrder: images.length }),
      });
      if (!res.ok) throw new Error();
      toast("Photo added", "success");
      setUrl("");
      setCaption("");
      setAddOpen(false);
      onChanged();
    } catch {
      toast("Could not add photo", "error");
    } finally {
      setSaving(false);
    }
  };

  if (images.length === 0 && !showAdmin) return null;

  return (
    <div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
        {images.map((img, i) => (
          <button
            key={img.id}
            type="button"
            onClick={() => setLightbox(i)}
            className={cn(
              "group relative overflow-hidden rounded-2xl bg-stone-200",
              i === 0 ? "col-span-2 row-span-2 aspect-square md:aspect-auto md:h-full md:min-h-[320px]" : "aspect-square"
            )}
          >
            <Image
              src={img.url}
              alt={img.caption || "Gallery photo"}
              fill
              sizes="(max-width: 768px) 50vw, 25vw"
              className="object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/60 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            {img.caption && (
              <span className="absolute bottom-3 left-3 right-3 truncate text-left text-sm font-medium text-white opacity-0 transition-opacity group-hover:opacity-100">
                {img.caption}
              </span>
            )}
            {showAdmin && (
              <span
                role="button"
                tabIndex={0}
                title="Delete photo"
                onClick={(e) => {
                  e.stopPropagation();
                  remove(img.id);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    remove(img.id);
                  }
                }}
                className="absolute right-2 top-2 rounded-full bg-white/95 p-2 text-stone-700 shadow transition hover:bg-rose-600 hover:text-white"
              >
                <Trash2 className="h-4 w-4" />
              </span>
            )}
          </button>
        ))}
        {showAdmin && (
          <button
            type="button"
            onClick={() => setAddOpen(true)}
            className="grid aspect-square place-items-center rounded-2xl border-2 border-dashed border-amber-500/60 bg-amber-50 text-amber-800 transition hover:bg-amber-100"
          >
            <span className="flex flex-col items-center gap-2 text-sm font-semibold">
              <ImagePlus className="h-8 w-8" /> Add photo
            </span>
          </button>
        )}
      </div>

      {/* Lightbox */}
      {lightbox !== null && images[lightbox] && (
        <div
          className="fixed inset-0 z-[75] grid place-items-center bg-stone-950/90 p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            type="button"
            className="absolute right-5 top-5 rounded-full bg-white/10 p-2.5 text-white transition hover:bg-white/20"
            onClick={() => setLightbox(null)}
          >
            <X className="h-6 w-6" />
          </button>
          {lightbox > 0 && (
            <button
              type="button"
              className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:left-6"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox(lightbox - 1);
              }}
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
          )}
          {lightbox < images.length - 1 && (
            <button
              type="button"
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/10 p-3 text-white transition hover:bg-white/20 sm:right-6"
              onClick={(e) => {
                e.stopPropagation();
                setLightbox(lightbox + 1);
              }}
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          )}
          <figure className="max-h-[85vh] w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <div className="relative h-[70vh] overflow-hidden rounded-2xl">
              <Image src={images[lightbox].url} alt={images[lightbox].caption} fill sizes="100vw" className="object-contain" />
            </div>
            {images[lightbox].caption && (
              <figcaption className="mt-3 text-center text-sm text-stone-300">
                {images[lightbox].caption}
              </figcaption>
            )}
          </figure>
        </div>
      )}

      {/* Add photo modal */}
      {addOpen && (
        <div className="fixed inset-0 z-[88] grid place-items-center bg-stone-950/70 p-4" onClick={() => setAddOpen(false)}>
          <form
            onSubmit={add}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
          >
            <h3 className="text-lg font-bold text-stone-900">Add a photo</h3>
            <label className="mb-1 mt-4 block text-xs font-semibold uppercase tracking-wide text-stone-500">
              Image URL *
            </label>
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://…"
              className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
            />
            {url && (
              <div className="relative mt-2 aspect-video overflow-hidden rounded-lg bg-stone-100">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={url} alt="Preview" className="h-full w-full object-cover" />
              </div>
            )}
            <label className="mb-1 mt-3 block text-xs font-semibold uppercase tracking-wide text-stone-500">
              Caption
            </label>
            <input
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Sunset over the terrace…"
              className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
            />
            <label className="mb-1 mt-3 block text-xs font-semibold uppercase tracking-wide text-stone-500">
              Category
            </label>
            <input
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
            />
            <button
              type="submit"
              disabled={saving || !url.trim()}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />} Add photo
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
