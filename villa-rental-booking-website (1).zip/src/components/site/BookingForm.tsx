"use client";

import { useMemo, useState } from "react";
import { CalendarCheck, CheckCircle2, Loader2 } from "lucide-react";
import type { Villa } from "@/db/schema";
import { useEdit } from "../edit/EditContext";
import { apiFetch } from "@/lib/client-auth";

export function BookingForm({
  villas,
  preselectedId,
}: {
  villas: Villa[];
  preselectedId: number | null;
}) {
  const { toast } = useEdit();
  const active = villas.filter((v) => v.active);
  const [villaId, setVillaId] = useState<string>(preselectedId ? String(preselectedId) : "");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState(2);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const selected = useMemo(
    () => active.find((v) => String(v.id) === villaId) ?? null,
    [active, villaId]
  );

  // Sync when a villa's "Request to book" button is clicked
  useMemo(() => {
    if (preselectedId) setVillaId(String(preselectedId));
  }, [preselectedId]);

  const nights = useMemo(() => {
    if (!checkIn || !checkOut) return 0;
    const diff = new Date(checkOut).getTime() - new Date(checkIn).getTime();
    return diff > 0 ? Math.round(diff / 86400000) : 0;
  }, [checkIn, checkOut]);

  const today = new Date().toISOString().slice(0, 10);
  const inputCls =
    "w-full rounded-xl border border-stone-300 bg-white px-4 py-3 text-sm text-stone-900 outline-none transition focus:border-amber-500 focus:ring-2 focus:ring-amber-200";
  const labelCls = "mb-1.5 block text-xs font-semibold uppercase tracking-wide text-stone-500";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      toast("Please add your name and email", "error");
      return;
    }
    setSending(true);
    try {
      const res = await apiFetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          villaId: villaId ? Number(villaId) : null,
          villaName: selected?.name ?? "Any villa",
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          checkIn,
          checkOut,
          guests,
          message: message.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "failed");
      setDone(true);
      toast("Request sent — we reply within 2 hours", "success");
    } catch (err) {
      toast(err instanceof Error ? err.message : "Could not send request", "error");
    } finally {
      setSending(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-3xl bg-white p-10 text-center shadow-xl">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-emerald-100 text-emerald-700">
          <CheckCircle2 className="h-8 w-8" />
        </span>
        <h3 className="mt-4 font-display text-2xl font-semibold text-stone-900">Request received!</h3>
        <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-stone-500">
          Thank you, {name.split(" ")[0]}. Our host will email you at{" "}
          <span className="font-semibold text-stone-700">{email}</span> within 2 hours with
          availability and your best rate.
        </p>
        <button
          type="button"
          onClick={() => setDone(false)}
          className="mt-6 rounded-xl border border-stone-300 px-5 py-2.5 text-sm font-semibold text-stone-700 transition hover:bg-stone-50"
        >
          Make another request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="rounded-3xl bg-white p-6 shadow-xl sm:p-8">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className={labelCls}>Villa</label>
          <select value={villaId} onChange={(e) => setVillaId(e.target.value)} className={inputCls}>
            <option value="">Any villa — surprise me</option>
            {active.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} — ${v.pricePerNight}/night · sleeps {v.maxGuests}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className={labelCls}>Check-in</label>
          <input type="date" min={today} value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Check-out</label>
          <input type="date" min={checkIn || today} value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Your name *</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Appleseed" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Email *</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@email.com" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Phone / WhatsApp</label>
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+1 555 000 1234" className={inputCls} />
        </div>
        <div>
          <label className={labelCls}>Guests</label>
          <input type="number" min={1} max={20} value={guests} onChange={(e) => setGuests(Number(e.target.value))} className={inputCls} />
        </div>
        <div className="sm:col-span-2">
          <label className={labelCls}>Anything we should know?</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            placeholder="Airport pickup, birthdays, dietary needs, surf lessons…"
            className={inputCls}
          />
        </div>
      </div>

      {selected && nights > 0 && (
        <div className="mt-4 flex items-center justify-between rounded-xl bg-amber-50 px-4 py-3 text-sm">
          <span className="text-amber-900">
            {nights} night{nights === 1 ? "" : "s"} × ${selected.pricePerNight}
          </span>
          <span className="font-display text-xl font-semibold text-amber-950">
            ≈ ${(nights * selected.pricePerNight).toLocaleString()}
          </span>
        </div>
      )}

      <button
        type="submit"
        disabled={sending}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-4 text-sm font-bold text-white transition hover:bg-amber-500 hover:text-amber-950 disabled:opacity-50"
      >
        {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalendarCheck className="h-4 w-4" />}
        Check availability
      </button>
      <p className="mt-3 text-center text-xs text-stone-400">No payment today · Free cancellation · Reply within 2 hours</p>
    </form>
  );
}
