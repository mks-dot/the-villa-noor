"use client";

import { useEffect, useMemo, useState } from "react";
import { Loader2, RotateCcw, Save, X } from "lucide-react";
import { useEdit } from "./EditContext";
import { DEFAULT_CONTENT } from "@/lib/defaults";
import { cn } from "@/lib/cn";

/** Slide-over panel: edit every text & image field on the page, grouped by section. */
export function ContentPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { content, saveMany, saving, refreshContent } = useEdit();
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState("");

  useEffect(() => {
    if (open) {
      setDrafts({ ...content });
      setFilter("");
    }
  }, [open, content]);

  const sections = useMemo(() => {
    const groups = new Map<string, typeof DEFAULT_CONTENT>();
    for (const def of DEFAULT_CONTENT) {
      if (filter && !`${def.label} ${def.key} ${def.section}`.toLowerCase().includes(filter.toLowerCase()))
        continue;
      if (!groups.has(def.section)) groups.set(def.section, []);
      groups.get(def.section)!.push(def);
    }
    return [...groups.entries()];
  }, [filter]);

  const dirty = useMemo(
    () => DEFAULT_CONTENT.filter((d) => (drafts[d.key] ?? "") !== (content[d.key] ?? "")),
    [drafts, content]
  );

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[85]">
      <div className="absolute inset-0 bg-stone-950/50 backdrop-blur-[2px]" onClick={onClose} />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-stone-200 px-5 py-4">
          <div>
            <h3 className="font-bold text-stone-900">Page content</h3>
            <p className="text-xs text-stone-500">
              {dirty.length === 0 ? "Everything is saved" : `${dirty.length} unsaved change${dirty.length === 1 ? "" : "s"}`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-1.5 text-stone-500 hover:bg-stone-100"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="border-b border-stone-200 px-5 py-3">
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="Search fields… (e.g. hero, phone)"
            className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
          />
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto px-5 py-4">
          {sections.map(([section, defs]) => (
            <div key={section}>
              <p className="mb-2 text-xs font-bold uppercase tracking-widest text-amber-700">
                {section}
              </p>
              <div className="space-y-3">
                {defs.map((def) => {
                  const isDirty = (drafts[def.key] ?? "") !== (content[def.key] ?? "");
                  return (
                    <div key={def.key}>
                      <label className="mb-1 flex items-center gap-2 text-xs font-semibold text-stone-600">
                        {def.label}
                        {isDirty && <span className="h-1.5 w-1.5 rounded-full bg-amber-500" />}
                      </label>
                      {def.type === "textarea" ? (
                        <textarea
                          value={drafts[def.key] ?? ""}
                          onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                          rows={3}
                          className={cn(
                            "w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-amber-200",
                            isDirty ? "border-amber-500" : "border-stone-300"
                          )}
                        />
                      ) : def.type === "image" ? (
                        <div className="space-y-2">
                          {drafts[def.key] ? (
                            <div className="relative aspect-video overflow-hidden rounded-lg bg-stone-100">
                              {/* eslint-disable-next-line @next/next/no-img-element */}
                              <img src={drafts[def.key]} alt={def.label} className="h-full w-full object-cover" />
                            </div>
                          ) : null}
                          <input
                            value={drafts[def.key] ?? ""}
                            onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                            placeholder="https://…"
                            className={cn(
                              "w-full rounded-lg border px-3 py-2 font-mono text-xs outline-none focus:ring-2 focus:ring-amber-200",
                              isDirty ? "border-amber-500" : "border-stone-300"
                            )}
                          />
                        </div>
                      ) : (
                        <input
                          value={drafts[def.key] ?? ""}
                          onChange={(e) => setDrafts((p) => ({ ...p, [def.key]: e.target.value }))}
                          className={cn(
                            "w-full rounded-lg border px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-amber-200",
                            isDirty ? "border-amber-500" : "border-stone-300"
                          )}
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
          {sections.length === 0 && (
            <p className="py-10 text-center text-sm text-stone-400">No fields match “{filter}”.</p>
          )}
        </div>

        <div className="flex gap-2 border-t border-stone-200 px-5 py-4">
          <button
            type="button"
            onClick={() => {
              setDrafts({ ...content });
            }}
            disabled={dirty.length === 0}
            className="flex items-center gap-2 rounded-xl border border-stone-300 px-4 py-2.5 text-sm font-semibold text-stone-600 transition hover:bg-stone-50 disabled:opacity-40"
          >
            <RotateCcw className="h-4 w-4" /> Reset
          </button>
          <button
            type="button"
            onClick={async () => {
              const ok = await saveMany(dirty.map((d) => ({ key: d.key, value: drafts[d.key] ?? "" })));
              if (ok) {
                await refreshContent();
                onClose();
              }
            }}
            disabled={saving || dirty.length === 0}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-stone-800 disabled:opacity-50"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save {dirty.length > 0 ? `(${dirty.length})` : ""}
          </button>
        </div>
      </aside>
    </div>
  );
}
