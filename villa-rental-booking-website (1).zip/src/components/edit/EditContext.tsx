"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { apiErrorMessage, apiFetch } from "@/lib/client-auth";

export type Toast = { id: number; message: string; kind: "success" | "error" | "info" };

type EditState = {
  isAdmin: boolean;
  editMode: boolean;
  content: Record<string, string>;
  contentLoaded: boolean;
  saving: boolean;
  toasts: Toast[];
  setEditMode: (v: boolean) => void;
  login: (password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updateContent: (key: string, value: string) => Promise<boolean>;
  saveMany: (items: { key: string; value: string }[]) => Promise<boolean>;
  refreshContent: () => Promise<void>;
  toast: (message: string, kind?: Toast["kind"]) => void;
  t: (key: string) => string;
};

const EditContext = createContext<EditState | null>(null);

let toastId = 1;

// NO LOGIN REQUIRED: everyone is admin, edit mode starts ON.
export function EditProvider({
  children,
  initialContent,
  initialIsAdmin,
}: {
  children: ReactNode;
  initialContent: Record<string, string>;
  initialIsAdmin: boolean;
}) {
  const isAdmin = true;
  void initialIsAdmin;
  const [editMode, setEditMode] = useState(true);
  const [content, setContent] = useState<Record<string, string>>(initialContent);
  const [contentLoaded, setContentLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((message: string, kind: Toast["kind"] = "success") => {
    const id = toastId++;
    setToasts((prev) => [...prev.slice(-3), { id, message, kind }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const refreshContent = useCallback(async () => {
    try {
      const res = await apiFetch("/api/content", { cache: "no-store" });
      if (!res.ok) return;
      const data = await res.json();
      const map: Record<string, string> = {};
      for (const row of data.content ?? []) map[row.key] = row.value;
      setContent((prev) => ({ ...prev, ...map }));
      setContentLoaded(true);
    } catch {
      /* offline — keep initial content */
    }
  }, []);

  useEffect(() => {
    refreshContent();
  }, [refreshContent]);

  // Kept for compatibility — always succeeds, no password needed.
  const login = useCallback(async (_password: string) => true, []);

  // Kept for compatibility — just turns edit mode off.
  const logout = useCallback(async () => {
    setEditMode(false);
  }, []);

  const updateContent = useCallback(
    async (key: string, value: string) => {
      setSaving(true);
      try {
        const res = await apiFetch("/api/content", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key, value }),
        });
        if (!res.ok) {
          toast(await apiErrorMessage(res, "Could not save"), "error");
          return false;
        }
        setContent((prev) => ({ ...prev, [key]: value }));
        toast("Saved ✓", "success");
        return true;
      } catch {
        toast("Cannot reach the server — check your connection.", "error");
        return false;
      } finally {
        setSaving(false);
      }
    },
    [toast]
  );

  const saveMany = useCallback(
    async (items: { key: string; value: string }[]) => {
      if (items.length === 0) return true;
      setSaving(true);
      try {
        const res = await apiFetch("/api/content", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ items }),
        });
        if (!res.ok) {
          toast(await apiErrorMessage(res, "Could not save"), "error");
          return false;
        }
        setContent((prev) => {
          const next = { ...prev };
          for (const i of items) next[i.key] = i.value;
          return next;
        });
        toast(`Saved ${items.length} change${items.length === 1 ? "" : "s"} ✓`, "success");
        return true;
      } catch {
        toast("Cannot reach the server — check your connection.", "error");
        return false;
      } finally {
        setSaving(false);
      }
    },
    [toast]
  );

  const t = useCallback((key: string) => content[key] ?? "", [content]);

  const value = useMemo<EditState>(
    () => ({
      isAdmin,
      editMode,
      content,
      contentLoaded,
      saving,
      toasts,
      setEditMode,
      login,
      logout,
      updateContent,
      saveMany,
      refreshContent,
      toast,
      t,
    }),
    [editMode, content, contentLoaded, saving, toasts, login, logout, updateContent, saveMany, refreshContent, toast, t]
  );

  return <EditContext.Provider value={value}>{children}</EditContext.Provider>;
}

export function useEdit() {
  const ctx = useContext(EditContext);
  if (!ctx) throw new Error("useEdit must be used inside EditProvider");
  return ctx;
}
