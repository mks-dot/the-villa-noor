"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { Check, ImagePlus, Loader2, X } from "lucide-react";
import { useEdit } from "./EditContext";
import { cn } from "@/lib/cn";
import { apiFetch } from "@/lib/client-auth";

type GalleryRow = { id: number; url: string; caption: string };

/** Click-to-swap image. In edit mode, click any editable photo to replace it. */
export function EditableImage({
  k,
  alt,
  className,
  imgClassName,
  sizes,
  priority,
}: {
  k: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  sizes?: string;
  priority?: boolean;
}) {
  const { editMode, t, updateContent } = useEdit();
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [gallery, setGallery] = useState<GalleryRow[]>([]);
  const [saving, setSaving] = useState(false);
  const src = t(k);

  useEffect(() => {
    if (open) {
      setDraft(src);
      apiFetch("/api/gallery")
        .then((r) => r.json())
        .then((d) => setGallery(d.gallery ?? []))
        .catch(() => {});
    }
  }, [open, src]);

  const save = async () => {
    if (!draft || draft === src) {
      setOpen(false);
      return;
    }
    setSaving(true);
    const ok = await updateContent(k, draft);
    setSaving(false);
    if (ok) setOpen(false);
  };

  return (
    <>
      <div
        className={cn("relative overflow-hidden", className)}
        onClick={
          editMode
            ? (e) => {
                e.stopPropagation();
                setOpen(true);
              }
            : undefined
        }
      >
        {src ? (
          <Image
            src={src}
            alt={alt}
            fill
            sizes={sizes ?? "100vw"}
            priority={priority}
            className={imgClassName ?? "object-cover"}
          />
        ) : (
          <div className="absolute inset-0 grid place-items-center bg-stone-200 text-stone-500">
            No image
          </div>
        )}
        {editMode && (
          <button
            type="button"
            title="Click to change image"
            className="absolute inset-0 flex cursor-pointer items-center justify-center gap-2 bg-amber-400/0 font-medium text-white opacity-0 transition-all hover:bg-amber-500/40 hover:opacity-100"
          >
            <span className="flex items-center gap-2 rounded-full bg-amber-950/90 px-4 py-2 text-sm">
              <ImagePlus className="h-4 w-4" /> Change image
            </span>
          </button>
        )}
      </div>

      {open && (
        <div
          className="fixed inset-0 z-[80] grid place-items-center bg-stone-950/70 p-4 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-stone-200 px-5 py-4">
              <h3 className="font-semibold text-stone-900">Change image</h3>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="rounded-full p-1.5 text-stone-500 hover:bg-stone-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-4 p-5">
              <div className="relative aspect-video overflow-hidden rounded-xl bg-stone-100">
                {draft ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={draft} alt="Preview" className="h-full w-full object-cover" />
                ) : (
                  <div className="grid h-full place-items-center text-sm text-stone-400">
                    Paste an image URL below
                  </div>
                )}
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-stone-500">
                  Image URL
                </label>
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="https://…"
                  className="w-full rounded-lg border border-stone-300 px-3 py-2 text-sm outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-200"
                />
              </div>
              {gallery.length > 0 && (
                <div>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-stone-500">
                    Or pick from gallery
                  </p>
                  <div className="grid max-h-40 grid-cols-4 gap-2 overflow-y-auto">
                    {gallery.map((g) => (
                      <button
                        key={g.id}
                        type="button"
                        onClick={() => setDraft(g.url)}
                        className={cn(
                          "relative aspect-square overflow-hidden rounded-lg border-2",
                          draft === g.url ? "border-amber-500" : "border-transparent"
                        )}
                      >
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={g.url} alt={g.caption} className="h-full w-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <button
                type="button"
                onClick={save}
                disabled={saving || !draft}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-stone-950 px-4 py-3 text-sm font-semibold text-white transition hover:bg-stone-800 disabled:opacity-50"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                Use this image
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
