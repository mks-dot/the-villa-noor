"use client";

import { useState } from "react";
import Link from "next/link";
import {
  CheckCircle2,
  Info,
  LayoutDashboard,
  Loader2,
  Pencil,
  SlidersHorizontal,
  XCircle,
} from "lucide-react";
import { useEdit } from "./EditContext";
import { ContentPanel } from "./ContentPanel";
import { cn } from "@/lib/cn";

// NO LOGIN REQUIRED: the edit toolbar is always available.
export function EditToolbar() {
  const { editMode, setEditMode, saving, toasts } = useEdit();
  const [panelOpen, setPanelOpen] = useState(false);

  return (
    <>
      {/* Toasts */}
      <div className="pointer-events-none fixed left-1/2 top-4 z-[100] flex -translate-x-1/2 flex-col items-center gap-2">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={cn(
              "pointer-events-auto flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium shadow-xl",
              toast.kind === "success" && "bg-emerald-600 text-white",
              toast.kind === "error" && "bg-rose-600 text-white",
              toast.kind === "info" && "bg-stone-900 text-white"
            )}
          >
            {toast.kind === "success" && <CheckCircle2 className="h-4 w-4" />}
            {toast.kind === "error" && <XCircle className="h-4 w-4" />}
            {toast.kind === "info" && <Info className="h-4 w-4" />}
            {toast.message}
          </div>
        ))}
      </div>

      {/* Floating toolbar — always visible, no login needed */}
      <div className="fixed bottom-5 left-1/2 z-[70] -translate-x-1/2">
        <div className="flex items-center gap-1 rounded-full border border-white/10 bg-stone-950/95 p-1.5 text-sm text-white shadow-2xl backdrop-blur">
          <span className="hidden items-center gap-2 px-3 text-xs font-medium text-stone-300 sm:flex">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
            </span>
            Edit mode
            {saving && <Loader2 className="h-3.5 w-3.5 animate-spin text-amber-300" />}
          </span>
          <button
            type="button"
            onClick={() => setEditMode(!editMode)}
            className={cn(
              "flex items-center gap-2 rounded-full px-4 py-2.5 font-semibold transition",
              editMode
                ? "bg-amber-400 text-amber-950 hover:bg-amber-300"
                : "bg-white/10 text-white hover:bg-white/20"
            )}
          >
            <Pencil className="h-4 w-4" />
            {editMode ? "Editing: On" : "Editing: Off"}
          </button>
          <button
            type="button"
            onClick={() => setPanelOpen(true)}
            className="hidden items-center gap-2 rounded-full px-4 py-2.5 font-medium text-stone-200 transition hover:bg-white/10 sm:flex"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Page content
          </button>
          <Link
            href="/admin"
            className="hidden items-center gap-2 rounded-full px-4 py-2.5 font-medium text-stone-200 transition hover:bg-white/10 sm:flex"
          >
            <LayoutDashboard className="h-4 w-4" />
            Dashboard
          </Link>
        </div>
      </div>

      <ContentPanel open={panelOpen} onClose={() => setPanelOpen(false)} />
    </>
  );
}
