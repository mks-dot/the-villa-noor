"use client";

import { useEffect, useRef, useState } from "react";
import { Pencil } from "lucide-react";
import { useEdit } from "./EditContext";
import { cn } from "@/lib/cn";

type Props = {
  k: string;
  className?: string;
  multiline?: boolean;
  as?: "h1" | "h2" | "h3" | "p" | "span" | "div";
  placeholder?: string;
};

/** Click-to-edit text. In edit mode, click any headline or paragraph to change it live. */
export function EditableText({ k, className, multiline, as = "span", placeholder }: Props) {
  const { editMode, t, updateContent } = useEdit();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const value = t(k);

  useEffect(() => {
    if (editing) {
      setDraft(value);
      requestAnimationFrame(() => inputRef.current?.focus());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing]);

  if (!editMode) {
    const Tag = as as "span";
    return <Tag className={className}>{value}</Tag>;
  }

  if (editing) {
    const save = async () => {
      setEditing(false);
      if (draft !== value) await updateContent(k, draft);
    };
    const shared = {
      value: draft,
      onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
        setDraft(e.target.value),
      onBlur: save,
      onKeyDown: async (e: React.KeyboardEvent) => {
        if (e.key === "Escape") setEditing(false);
        if (e.key === "Enter" && !multiline) {
          e.preventDefault();
          await save();
        }
        if (e.key === "Enter" && (e.metaKey || e.ctrlKey) && multiline) {
          e.preventDefault();
          await save();
        }
      },
      placeholder: placeholder ?? "Type something…",
      className: cn(
        "w-full rounded-lg border-2 border-amber-400 bg-white px-3 py-1.5 text-inherit shadow-xl outline-none",
        className
      ),
    };
    return multiline ? (
      <textarea
        {...shared}
        ref={inputRef as React.Ref<HTMLTextAreaElement>}
        rows={Math.min(6, Math.max(2, draft.split("\n").length + 1))}
      />
    ) : (
      <input {...shared} ref={inputRef as React.Ref<HTMLInputElement>} />
    );
  }

  const Tag = as as "span";
  return (
    <Tag
      onClick={(e) => {
        e.stopPropagation();
        setEditing(true);
      }}
      title="Click to edit"
      className={cn(
        "group/editable relative cursor-text rounded-md transition-all hover:bg-amber-300/30 hover:shadow-[0_0_0_2px_rgba(251,191,36,0.7)]",
        className
      )}
    >
      {value || <span className="opacity-40">{placeholder ?? "Click to add text"}</span>}
      <span className="pointer-events-none absolute -right-2 -top-2 hidden rounded-full bg-amber-400 p-1 text-amber-950 shadow group-hover/editable:block">
        <Pencil className="h-3 w-3" />
      </span>
    </Tag>
  );
}
