import { NextRequest, NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { villas } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { isAdminRequest } from "@/lib/auth";

function slugify(name: string) {
  return (
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") || `villa-${Date.now()}`
  );
}

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(villas).orderBy(asc(villas.sortOrder), asc(villas.id));
  return NextResponse.json({ villas: rows });
}

export async function POST(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const body = await req.json().catch(() => ({}));
  if (!body.name || typeof body.name !== "string") {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }
  try {
    const images = Array.isArray(body.images) ? body.images.filter(Boolean) : [];
    const amenities = Array.isArray(body.amenities) ? body.amenities.filter(Boolean) : [];
    const [created] = await db
      .insert(villas)
      .values({
        name: body.name,
        slug: body.slug || `${slugify(body.name)}-${Date.now().toString(36)}`,
        tagline: body.tagline ?? "",
        description: body.description ?? "",
        pricePerNight: Number(body.pricePerNight) || 0,
        bedrooms: Number(body.bedrooms) || 1,
        bathrooms: Number(body.bathrooms) || 1,
        maxGuests: Number(body.maxGuests) || 2,
        sizeSqm: Number(body.sizeSqm) || 0,
        coverImage: body.coverImage ?? images[0] ?? "",
        images,
        amenities,
        featured: body.featured !== false,
        active: body.active !== false,
        sortOrder: Number(body.sortOrder) || 0,
      })
      .returning();
    return NextResponse.json({ villa: created }, { status: 201 });
  } catch (err) {
    console.error("Villa create failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}
