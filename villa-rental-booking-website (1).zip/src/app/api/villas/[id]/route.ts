import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { villas } from "@/db/schema";
import { isAdminRequest } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  try {
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    const fields = [
      "name",
      "slug",
      "tagline",
      "description",
      "coverImage",
      "pricePerNight",
      "bedrooms",
      "bathrooms",
      "maxGuests",
      "sizeSqm",
      "sortOrder",
      "featured",
      "active",
    ] as const;
    for (const f of fields) {
      if (body[f] !== undefined) {
        patch[f] =
          ["pricePerNight", "bedrooms", "bathrooms", "maxGuests", "sizeSqm", "sortOrder"].includes(f)
            ? Number(body[f]) || 0
            : body[f];
      }
    }
    if (Array.isArray(body.images)) patch.images = body.images.filter(Boolean);
    if (Array.isArray(body.amenities)) patch.amenities = body.amenities.filter(Boolean);
    const [updated] = await db.update(villas).set(patch).where(eq(villas.id, Number(id))).returning();
    if (!updated) return NextResponse.json({ error: "Villa not found" }, { status: 404 });
    return NextResponse.json({ villa: updated });
  } catch (err) {
    console.error("Villa update failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  try {
    await db.delete(villas).where(eq(villas.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Villa delete failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while deleting." },
      { status: 500 }
    );
  }
}
