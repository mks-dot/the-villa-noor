import { NextRequest, NextResponse } from "next/server";

// NO LOGIN REQUIRED mode: editing is open, no password needed.

export async function GET(_req: NextRequest) {
  return NextResponse.json({ isAdmin: true });
}

export async function POST(_req: NextRequest) {
  return NextResponse.json({ ok: true, token: "no-login-required" });
}

export async function DELETE() {
  return NextResponse.json({ ok: true });
}
