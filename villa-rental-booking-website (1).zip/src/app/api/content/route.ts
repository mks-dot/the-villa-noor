import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { siteContent } from "@/db/schema";
import { DEFAULT_CONTENT } from "@/lib/defaults";
import { ensureSeeded } from "@/lib/seed";
import { isAdminRequest } from "@/lib/auth";

export async function GET() {
  await ensureSeeded();
  const rows = await db.select().from(siteContent);
  const byKey = new Map(rows.map((r) => [r.key, r]));
  const merged = DEFAULT_CONTENT.map((def) => {
    const row = byKey.get(def.key);
    return {
      key: def.key,
      value: row?.value ?? def.value,
      type: def.type,
      label: def.label,
      section: def.section,
    };
  });
  return NextResponse.json({ content: merged });
}

export async function PUT(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const body = await req.json().catch(() => ({}));
  const items: { key: string; value: string }[] = Array.isArray(body.items)
    ? body.items
    : body.key
      ? [{ key: body.key, value: String(body.value ?? "") }]
      : [];
  if (items.length === 0) {
    return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
  }
  try {
    const defs = new Map(DEFAULT_CONTENT.map((d) => [d.key, d]));
    for (const item of items) {
      if (!item.key) continue;
      const def = defs.get(item.key);
      await db
        .insert(siteContent)
        .values({
          key: item.key,
          value: String(item.value ?? ""),
          type: def?.type ?? "text",
          label: def?.label ?? item.key,
          section: def?.section ?? "general",
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: siteContent.key,
          set: { value: String(item.value ?? ""), updatedAt: new Date() },
        });
    }
    return NextResponse.json({ ok: true, updated: items.length });
  } catch (err) {
    console.error("Content save failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}
