import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { isAdminRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  await ensureSeeded();
  const showAll = req.nextUrl.searchParams.get("all") === "1";
  if (showAll) {
    if (!isAdminRequest(req)) {
      return NextResponse.json(
        { error: "Not logged in as admin. Please log in again and retry." },
        { status: 401 }
      );
    }
    const rows = await db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
    return NextResponse.json({ testimonials: rows });
  }
  const rows = await db
    .select()
    .from(testimonials)
    .where(eq(testimonials.approved, true))
    .orderBy(desc(testimonials.createdAt));
  return NextResponse.json({ testimonials: rows });
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (!body.guestName || !body.text) {
    return NextResponse.json({ error: "Name and review text are required" }, { status: 400 });
  }
  try {
    const [created] = await db
      .insert(testimonials)
      .values({
        guestName: body.guestName,
        location: body.location ?? "",
        villaName: body.villaName ?? "",
        rating: Math.min(5, Math.max(1, Number(body.rating) || 5)),
        text: body.text,
        stayDate: body.stayDate ?? "",
        approved: false, // every new review needs approval in the dashboard
      })
      .returning();
    return NextResponse.json({ testimonial: created }, { status: 201 });
  } catch (err) {
    console.error("Review submit failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}
