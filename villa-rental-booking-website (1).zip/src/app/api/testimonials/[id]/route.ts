import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { isAdminRequest } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  try {
    const patch: Record<string, unknown> = {};
    for (const f of ["guestName", "location", "villaName", "text", "stayDate", "approved"] as const) {
      if (body[f] !== undefined) patch[f] = body[f];
    }
    if (body.rating !== undefined) patch.rating = Math.min(5, Math.max(1, Number(body.rating) || 5));
    const [updated] = await db
      .update(testimonials)
      .set(patch)
      .where(eq(testimonials.id, Number(id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Review not found" }, { status: 404 });
    return NextResponse.json({ testimonial: updated });
  } catch (err) {
    console.error("Review update failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  try {
    await db.delete(testimonials).where(eq(testimonials.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Review delete failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while deleting." },
      { status: 500 }
    );
  }
}
