import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { galleryImages } from "@/db/schema";
import { isAdminRequest } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  try {
    const patch: Record<string, unknown> = {};
    if (body.url !== undefined) patch.url = body.url;
    if (body.caption !== undefined) patch.caption = body.caption;
    if (body.category !== undefined) patch.category = body.category;
    if (body.sortOrder !== undefined) patch.sortOrder = Number(body.sortOrder) || 0;
    const [updated] = await db
      .update(galleryImages)
      .set(patch)
      .where(eq(galleryImages.id, Number(id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Photo not found" }, { status: 404 });
    return NextResponse.json({ image: updated });
  } catch (err) {
    console.error("Gallery update failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  try {
    await db.delete(galleryImages).where(eq(galleryImages.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Gallery delete failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while deleting." },
      { status: 500 }
    );
  }
}
