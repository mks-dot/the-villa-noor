import { NextRequest, NextResponse } from "next/server";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { galleryImages } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { isAdminRequest } from "@/lib/auth";

export async function GET() {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(galleryImages)
    .orderBy(asc(galleryImages.sortOrder), asc(galleryImages.id));
  return NextResponse.json({ gallery: rows });
}

export async function POST(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const body = await req.json().catch(() => ({}));
  if (!body.url) return NextResponse.json({ error: "Image URL is required" }, { status: 400 });
  try {
    const [created] = await db
      .insert(galleryImages)
      .values({
        url: body.url,
        caption: body.caption ?? "",
        category: body.category ?? "Villa",
        sortOrder: Number(body.sortOrder) || 0,
      })
      .returning();
    return NextResponse.json({ image: created }, { status: 201 });
  } catch (err) {
    console.error("Gallery add failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}
