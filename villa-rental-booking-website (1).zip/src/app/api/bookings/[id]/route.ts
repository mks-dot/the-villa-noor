import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { isAdminRequest } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  try {
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const f of ["status", "villaName", "name", "email", "phone", "checkIn", "checkOut", "message"] as const) {
      if (body[f] !== undefined) patch[f] = body[f];
    }
    if (body.guests !== undefined) patch.guests = Number(body.guests) || 1;
    const [updated] = await db
      .update(bookings)
      .set(patch)
      .where(eq(bookings.id, Number(id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    return NextResponse.json({ booking: updated });
  } catch (err) {
    console.error("Booking update failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  const { id } = await ctx.params;
  try {
    await db.delete(bookings).where(eq(bookings.id, Number(id)));
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Booking delete failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while deleting." },
      { status: 500 }
    );
  }
}
