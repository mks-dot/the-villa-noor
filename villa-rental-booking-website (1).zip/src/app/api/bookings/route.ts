import { NextRequest, NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { isAdminRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  if (!isAdminRequest(req)) {
    return NextResponse.json(
      { error: "Not logged in as admin. Please log in again and retry." },
      { status: 401 }
    );
  }
  await ensureSeeded();
  const rows = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  return NextResponse.json({ bookings: rows });
}

export async function POST(req: NextRequest) {
  await ensureSeeded();
  const body = await req.json().catch(() => ({}));
  if (!body.name || !body.email) {
    return NextResponse.json({ error: "Name and email are required" }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    return NextResponse.json({ error: "Please enter a valid email" }, { status: 400 });
  }
  try {
    const [created] = await db
      .insert(bookings)
      .values({
        villaId: body.villaId ? Number(body.villaId) : null,
        villaName: body.villaName ?? "",
        name: body.name,
        email: body.email,
        phone: body.phone ?? "",
        checkIn: body.checkIn ?? "",
        checkOut: body.checkOut ?? "",
        guests: Number(body.guests) || 2,
        message: body.message ?? "",
        status: "pending",
      })
      .returning();
    return NextResponse.json({ booking: created }, { status: 201 });
  } catch (err) {
    console.error("Booking submit failed:", err);
    return NextResponse.json(
      { error: err instanceof Error ? `Database error: ${err.message}` : "Database error while saving." },
      { status: 500 }
    );
  }
}
