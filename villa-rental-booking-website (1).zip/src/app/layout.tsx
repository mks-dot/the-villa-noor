import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Azura Villas — Private Luxury Villas in Bali",
  description:
    "Modern 2-bedroom, 2-bathroom villas with designer interiors, full kitchens and terraces in Uluwatu, Bali. Book direct for the best rate.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-stone-50 font-sans text-stone-900 antialiased">{children}</body>
    </html>
  );
}
