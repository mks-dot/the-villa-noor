import { asc, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { galleryImages, siteContent, testimonials, villas } from "@/db/schema";
import { isAdmin } from "@/lib/auth";
import { DEFAULT_CONTENT } from "@/lib/defaults";
import { ensureSeeded } from "@/lib/seed";
import { VillaSite } from "@/components/site/VillaSite";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureSeeded();
  const [contentRows, villaRows, galleryRows, reviewRows, admin] = await Promise.all([
    db.select().from(siteContent),
    db.select().from(villas).orderBy(asc(villas.sortOrder), asc(villas.id)),
    db.select().from(galleryImages).orderBy(asc(galleryImages.sortOrder), asc(galleryImages.id)),
    db
      .select()
      .from(testimonials)
      .where(eq(testimonials.approved, true))
      .orderBy(desc(testimonials.createdAt)),
    isAdmin(),
  ]);

  const content: Record<string, string> = {};
  for (const def of DEFAULT_CONTENT) content[def.key] = def.value;
  for (const row of contentRows) content[row.key] = row.value;

  return (
    <VillaSite
      initialContent={content}
      initialIsAdmin={admin}
      initialVillas={villaRows}
      initialGallery={galleryRows}
      initialReviews={reviewRows}
    />
  );
}
