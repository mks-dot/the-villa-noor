import { db } from "@/db";
import { siteContent } from "@/db/schema";
import { isAdmin } from "@/lib/auth";
import { DEFAULT_CONTENT } from "@/lib/defaults";
import { ensureSeeded } from "@/lib/seed";
import { EditProvider } from "@/components/edit/EditContext";
import { AdminDashboard } from "@/components/admin/AdminDashboard";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  await ensureSeeded();
  const [contentRows, admin] = await Promise.all([db.select().from(siteContent), isAdmin()]);
  const content: Record<string, string> = {};
  for (const def of DEFAULT_CONTENT) content[def.key] = def.value;
  for (const row of contentRows) content[row.key] = row.value;

  return (
    <EditProvider initialContent={content} initialIsAdmin={admin}>
      <AdminDashboard />
    </EditProvider>
  );
}
