# Azura Villas — villa website with visual edit tool

Next.js (App Router) + PostgreSQL (Drizzle ORM) + Tailwind CSS.

## Run locally

```bash
npm install
cp .env.example .env   # then set DATABASE_URL to your Postgres
npx drizzle-kit push   # optional — the app also creates tables on first visit
npm run dev
```

## Deploy to Vercel

1. Push this folder to a GitHub repository.
2. On [vercel.com](https://vercel.com) click **Add New → Project** and import the repo.
3. Before/after the first deploy, open the project → **Storage → Create → Postgres**.
   Vercel automatically adds `DATABASE_URL` (or `POSTGRES_URL`) to the project.
4. **Redeploy** once after adding storage (so the new env var is picked up).
5. Open your `https://<project>.vercel.app` URL — the first visit creates
   all tables and seeds the starter villas, photos and texts automatically.

Editing is open (no login): click the **Editing** pill at the bottom of the
site, then click any text or photo to change it. Dashboard lives at `/admin`.
